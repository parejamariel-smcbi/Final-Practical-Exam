<?php
if (session_status() === PHP_SESSION_NONE) session_start();

// Check DB connection (in case navbar is included in a file without it)
if (!isset($conn)) { include 'db.php'; }

$isLoggedIn = isset($_SESSION['user_id']);
$cartCount = isset($_SESSION['cart']) ? array_sum(array_column($_SESSION['cart'], 'quantity')) : 0;

// --- NEW: Ensure Session has the latest Image ---
if ($isLoggedIn && !isset($_SESSION['profile_image'])) {
    $stmt = $conn->prepare("SELECT profile_image FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $_SESSION['profile_image'] = $res['profile_image'] ?? null;
}
?>

<style>
    /* --- OPTION 3: FLOATING GLASS ISLAND NAVBAR --- */
    .pizza-navbar {
        background: rgba(255, 255, 255, 0.85);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border-bottom: 1px solid rgba(255, 255, 255, 0.3);
        box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.1);
        padding: 15px 0;
        transition: all 0.3s ease;
        
        /* Floating Island Look (Desktop) */
        margin: 20px auto;
        width: 95%;
        max-width: 1200px;
        border-radius: 50px;
    }
    
    /* Fix width on mobile */
    @media (max-width: 991px) {
        .pizza-navbar {
            width: 100%;
            margin: 0;
            border-radius: 0;
            padding: 10px 0;
        }
        /* Ensure mobile menu has a background */
        .navbar-collapse {
            background: rgba(255, 255, 255, 0.95);
            padding: 20px;
            border-radius: 20px;
            margin-top: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
    }

    /* Logo Styling */
    .navbar-brand img {
        height: 50px; 
        width: auto;
        transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }
    .navbar-brand:hover img {
        transform: scale(1.2) rotate(-5deg);
    }

    /* Link Styling */
    .nav-link {
        font-family: 'Poppins', sans-serif;
        font-weight: 600;
        color: #333 !important;
        margin: 0 15px;
        position: relative;
        transition: color 0.3s;
    }
    .nav-link:hover {
        color: #d32f2f !important;
    }

    /* Bouncing Icon Effect */
    .nav-link i {
        display: inline-block;
        transition: transform 0.3s;
    }
    .nav-link:hover i {
        transform: translateY(-3px);
    }

    /* Active Indicator (Dot) */
    .nav-link.active::after {
        content: '';
        position: absolute;
        width: 6px;
        height: 6px;
        background: #d32f2f;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        border-radius: 50%;
    }

    /* Cart Button (Gradient) */
    .btn-cart {
        background: linear-gradient(45deg, #d32f2f, #ff5252);
        color: white;
        border: none;
        font-weight: bold;
        box-shadow: 0 4px 15px rgba(211, 47, 47, 0.4);
        transition: all 0.3s;
    }
    .btn-cart:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 20px rgba(211, 47, 47, 0.6);
        color: white;
    }

    /* Mobile Toggler */
    .navbar-toggler { border: none; }
    .navbar-toggler:focus { box-shadow: none; }
    .navbar-toggler-icon {
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.8)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
    }

    /* Password Toggle Button */
    .password-toggle {
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: #6c757d;
        cursor: pointer;
        padding: 5px 10px;
        z-index: 10;
    }
    .password-toggle:hover {
        color: #495057;
    }
    .password-wrapper {
        position: relative;
    }

    /* --- NEW: AVATAR STYLES --- */
    .nav-avatar-img {
        width: 30px; height: 30px; object-fit: cover; 
        border-radius: 50%; border: 1px solid #ccc;
    }
    .nav-initials {
        width: 30px; height: 30px;
        background: #0d6efd; color: white;
        display: inline-flex; align-items: center; justify-content: center;
        border-radius: 50%; font-weight: bold; font-size: 0.8rem;
    }
</style>

<div class="container-fluid sticky-top p-0" style="z-index: 1030;">
    <nav class="navbar navbar-expand-lg pizza-navbar">
      <div class="container-fluid px-4">
        
        <a class="navbar-brand d-flex align-items-center gap-2" href="main.php">
          <img src="icon.png" alt="Pizza Hut">
          <span style="font-family: 'Chewy', cursive; font-size: 1.5rem; color: #d32f2f;">Pizza Hut</span>
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
    
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto align-items-center">
            <li class="nav-item"><a class="nav-link" href="main.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="menu.php">Menu</a></li>
            <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
    
            <?php if (empty($_SESSION['is_admin'])): ?>
            <li class="nav-item mx-lg-2 mt-2 mt-lg-0">
                <a href="order.php" class="btn btn-cart position-relative rounded-pill px-4 py-2">
                    <i class="bi bi-bag-fill me-1"></i> Cart
                    <?php if($cartCount > 0): ?>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-circle bg-dark text-white border border-white">
                            <?= $cartCount ?>
                        </span>
                    <?php endif; ?>
                </a>
            </li>
            <?php endif; ?>
    
            <li class="nav-item mx-2 d-none d-lg-block"><span class="text-muted opacity-25">|</span></li>
    
            <?php if ($isLoggedIn): ?>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-dark d-flex align-items-center" href="javascript:void(0);" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    
                    <?php if (!empty($_SESSION['profile_image']) && file_exists('uploads/' . $_SESSION['profile_image'])): ?>
                        <img src="uploads/<?= $_SESSION['profile_image'] ?>" class="nav-avatar-img me-2">
                    <?php else: ?>
                        <div class="nav-initials me-2">
                            <?= strtoupper(substr($_SESSION['username'] ?? 'U', 0, 1)) ?>
                        </div>
                    <?php endif; ?>
                    Hi, <?= htmlspecialchars($_SESSION['username'] ?? 'User') ?>
                </a>
                <ul class="dropdown-menu dropdown-menu-end border-0 shadow-lg mt-3 rounded-4 overflow-hidden p-1">
                  <?php if (!empty($_SESSION['is_admin'])): ?>
                    <li><a class="dropdown-item fw-bold text-danger rounded-3" href="admin.php"><i class="bi bi-speedometer2 me-2"></i> Admin Panel</a></li>
                  <?php endif; ?>
                  <li><a class="dropdown-item rounded-3" href="profile.php"><i class="bi bi-person me-2"></i> My Profile</a></li>
                  <li><hr class="dropdown-divider my-1"></li>
                  <li><a class="dropdown-item text-danger rounded-3" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
                </ul>
              </li>
              
            <?php else: ?>
              <li class="nav-item ms-lg-2 mt-2 mt-lg-0">
                <button class="btn btn-outline-danger rounded-pill px-4 fw-bold border-2" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>
              </li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </nav>
</div>

<div class="modal fade" id="loginModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content rounded-4 border-0 shadow-lg overflow-hidden">
      <div class="modal-header bg-dark text-white border-0">
        <h5 class="modal-title fw-bold font-monospace"><i class="bi bi-person-badge-fill me-2"></i>Welcome Back!</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-4">
        <div id="loginMessage" class="alert alert-danger d-none rounded-3"></div>
        <form id="loginForm">
            <div class="form-floating mb-3">
                <input type="email" name="email" class="form-control rounded-3" id="loginEmail" placeholder="name@example.com" required>
                <label for="loginEmail">Email Address</label>
            </div>
            <div class="form-floating mb-3 password-wrapper">
                <input type="password" name="password" class="form-control rounded-3" id="loginPass" placeholder="Password" required>
                <label for="loginPass">Password</label>
                <button type="button" class="password-toggle" onclick="togglePassword('loginPass', this)">
                    <i class="bi bi-eye"></i>
                </button>
            </div>
            <div class="text-end mb-3">
    <a href="forgot_password.php" class="text-decoration-none text-muted small">Forgot Password?</a>
</div>
            <button type="submit" class="btn btn-dark w-100 fw-bold py-2 rounded-pill shadow-sm">LOGIN</button>
        </form>
        <div class="text-center mt-4">
            <small class="text-muted">New here? <a href="javascript:void(0);" role="button" class="fw-bold text-danger text-decoration-none" data-bs-toggle="modal" data-bs-target="#signupModal" data-bs-dismiss="modal">Create an account</a></small>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="signupModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content rounded-4 border-0 shadow-lg overflow-hidden">
      <div class="modal-header bg-warning text-dark border-0">
        <h5 class="modal-title fw-bold font-monospace"><i class="bi bi-pencil-square me-2"></i>Join the Family</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-4">
        <div id="signupMessage" class="alert alert-danger d-none rounded-3"></div>
        <form id="signupForm">
            <div class="form-floating mb-2">
                <input type="text" name="username" class="form-control rounded-3" id="signUser" placeholder="Username" required>
                <label for="signUser">Username</label>
            </div>
            <div class="form-floating mb-2">
                <input type="email" name="email" class="form-control rounded-3" id="signEmail" placeholder="name@example.com" required>
                <label for="signEmail">Email Address</label>
            </div>
            <div class="form-floating mb-2">
                <input type="text" name="address" class="form-control rounded-3" id="signAddress" placeholder="Address" required>
                <label for="signAddress">Delivery Address</label>
            </div>
            <div class="form-floating mb-2 password-wrapper">
                <input type="password" name="password" class="form-control rounded-3" id="signPass" placeholder="Password" required minlength="8">
                <label for="signPass">Password (Min 8 chars)</label>
                <button type="button" class="password-toggle" onclick="togglePassword('signPass', this)">
                    <i class="bi bi-eye"></i>
                </button>
            </div>
            <div class="form-floating mb-3 password-wrapper">
                <input type="password" class="form-control rounded-3" id="signPassConfirm" placeholder="Confirm Password" required minlength="8">
                <label for="signPassConfirm">Confirm Password</label>
                <button type="button" class="password-toggle" onclick="togglePassword('signPassConfirm', this)">
                    <i class="bi bi-eye"></i>
                </button>
            </div>
            <button type="submit" class="btn btn-warning w-100 fw-bold py-2 rounded-pill shadow-sm">SIGN UP</button>
        </form>
        <div class="text-center mt-4">
             <small class="text-muted">Already a member? <a href="javascript:void(0);" role="button" class="fw-bold text-warning text-decoration-none" data-bs-toggle="modal" data-bs-target="#loginModal" data-bs-dismiss="modal">Login here</a></small>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
// Toggle Password Visibility
function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);
    const icon = button.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('bi-eye');
        icon.classList.add('bi-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('bi-eye-slash');
        icon.classList.add('bi-eye');
    }
}

document.addEventListener('DOMContentLoaded', function() {
    // Login Logic
    const loginForm = document.getElementById('loginForm');
    if(loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            fetch('login.php', { method: 'POST', body: new URLSearchParams(new FormData(loginForm)) })
            .then(r => r.json()).then(d => {
                if(d.success) location.reload();
                else {
                    const msg = document.getElementById('loginMessage');
                    msg.textContent = d.message; msg.classList.remove('d-none');
                }
            });
        });
    }
    
    // Signup Logic with Password Confirmation
    const signupForm = document.getElementById('signupForm');
    if(signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const password = document.getElementById('signPass').value;
            const confirmPassword = document.getElementById('signPassConfirm').value;
            const msg = document.getElementById('signupMessage');
            
            // Check if passwords match
            if (password !== confirmPassword) {
                msg.textContent = 'Passwords do not match!';
                msg.classList.remove('d-none');
                return;
            }
            
            fetch('signup.php', { method: 'POST', body: new URLSearchParams(new FormData(signupForm)) })
            .then(r => r.json()).then(d => {
                if(d.success) location.reload();
                else {
                    msg.textContent = d.message; 
                    msg.classList.remove('d-none');
                }
            });
        });
    }
});
</script>