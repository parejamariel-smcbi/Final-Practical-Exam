<?php
session_start();
include 'db.php';

header('Content-Type: application/json');

// 1. Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in.']);
    exit;
}

// --- FIX: BLOCK ADMINS ---
if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {
    echo json_encode(['success' => false, 'message' => 'Owners/Admins cannot place orders.']);
    exit;
}
// -------------------------

$pizzaId = filter_input(INPUT_POST, 'pizza_id', FILTER_VALIDATE_INT);
$quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);

// 2. Basic validation
if (!$pizzaId || $quantity < 1) {
    echo json_encode(['success' => false, 'message' => 'Invalid pizza or quantity.']);
    exit;
}

// 3. Fetch pizza details
$stmt = $conn->prepare("SELECT name, price FROM pizzas WHERE id = ?");
$stmt->bind_param("i", $pizzaId);
$stmt->execute();
$result = $stmt->get_result();
$pizza = $result->fetch_assoc();
$stmt->close();

if (!$pizza) {
    echo json_encode(['success' => false, 'message' => 'Pizza not found.']);
    exit;
}

// 4. Initialize cart
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// 5. Add/Update cart
if (isset($_SESSION['cart'][$pizzaId])) {
    $_SESSION['cart'][$pizzaId]['quantity'] += $quantity; 
} else {
    $_SESSION['cart'][$pizzaId] = [
        'name' => $pizza['name'],
        'price' => $pizza['price'],
        'quantity' => $quantity
    ];
}

echo json_encode(['success' => true, 'message' => 'Added to cart!']);
?>