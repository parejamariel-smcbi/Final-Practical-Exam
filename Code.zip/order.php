<?php
session_start();
include 'db.php'; 

$isLoggedIn = isset($_SESSION['user_id']);
$cart = $_SESSION['cart'] ?? [];
$grandTotal = 0;
$pizzasInCart = [];
$userAddress = "";

if (!empty($cart) && $conn) {
    $pizzaIds = array_keys($cart);
    if (!empty($pizzaIds)) {
        $inClause = implode(',', array_map('intval', $pizzaIds));
        $sql = "SELECT id, name, price, description, image FROM pizzas WHERE id IN ($inClause)";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $pizzasInCart[$row['id']] = $row;
        }
    }
}

if ($isLoggedIn) {
    $stmt = $conn->prepare("SELECT address FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $res = $stmt->get_result();
    if($u = $res->fetch_assoc()) $userAddress = $u['address'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>My Cart | Pizza Hut</title>
  <link rel="icon" href="icon.png" type="image/png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Chewy&family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <style>
    body { font-family: 'Poppins', sans-serif; background-color: #f4f4f4; }
    h1, h3 { font-family: 'Chewy', cursive; }
    .cart-img { width: 80px; height: 80px; object-fit: cover; border-radius: 10px; }
    
    .payment-card {
        border: 2px solid #e0e0e0; border-radius: 15px; padding: 20px;
        margin-bottom: 15px; cursor: pointer; transition: all 0.3s ease;
        background: white; position: relative; overflow: hidden;
    }
    .payment-card:hover { border-color: #ffca28; transform: translateX(5px); box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
    .payment-card.active {
        border-color: #d32f2f; background: linear-gradient(135deg, #fff5f5 0%, #ffffff 100%);
        box-shadow: 0 8px 25px rgba(211, 47, 47, 0.15);
    }
    .payment-icon {
        width: 60px; height: 60px; border-radius: 12px;
        display: flex; align-items: center; justify-content: center;
        font-size: 2rem; flex-shrink: 0;
    }
    
    .gcash-box {
        background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
        border-radius: 15px; padding: 25px; margin-top: 20px;
        border: 2px solid #2196f3; display: none; animation: slideDown 0.4s ease;
    }
    .gcash-box.show { display: block; }
    @keyframes slideDown { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
    
    /* GLASS MODAL CSS */
    .glass-modal {
        background: rgba(255, 255, 255, 0.8); /* Less transparent to be readable */
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.6);
        box-shadow: 0 15px 40px rgba(0,0,0,0.2);
        border-radius: 20px;
    }
    
    /* --- NEW: CUSTOM DARK BACKDROP --- */
    .modal-backdrop.show {
        opacity: 0.7 !important; /* Make it darker (default is 0.5) */
        background-color: #000 !important;
        backdrop-filter: blur(5px); /* Blurs the background website */
    }
  </style>
</head>
<body class="d-flex flex-column min-vh-100">

  <?php include 'navbar.php'; ?>

  <div class="container py-5 flex-grow-1">
    <h1 class="text-center mb-5 text-danger">Your Cart 🛒</h1>

    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="alert alert-danger text-center"><?= $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
    <?php endif; ?>

    <div class="row g-4">
      <div class="col-lg-8">
        <?php if (empty($cart)): ?>
            <div class="text-center py-5 bg-white rounded shadow-sm">
                <i class="bi bi-cart-x display-1 text-muted opacity-50"></i>
                <h3 class="mt-3">Your cart is empty</h3>
                <a href="menu.php" class="btn btn-danger mt-3 rounded-pill px-4 fw-bold">Browse Menu</a>
            </div>
        <?php else: ?>
            <?php foreach ($cart as $pizzaId => $item): 
                $pizza = $pizzasInCart[$pizzaId] ?? null;
                if(!$pizza) continue;
                $subtotal = $pizza['price'] * $item['quantity'];
                $grandTotal += $subtotal;
            ?>
            <div class="card p-3 mb-3 border-0 shadow-sm rounded-4">
                <div class="d-flex align-items-center gap-3">
                    <img src="<?= htmlspecialchars($pizza['image']) ?>" class="cart-img">
                    <div class="flex-grow-1">
                        <h5 class="mb-0"><?= htmlspecialchars($pizza['name']) ?></h5>
                        <small class="text-muted">Price: ₱<?= number_format($pizza['price'], 2) ?></small>
                        <div class="d-flex justify-content-between mt-2">
                            <span class="fw-bold">Qty: <?= $item['quantity'] ?></span>
                            <span class="fw-bold text-danger">₱<?= number_format($subtotal, 2) ?></span>
                        </div>
                    </div>
                    <button class="btn btn-sm btn-light text-danger remove-btn rounded-circle" data-pizza-id="<?= $pizzaId ?>">
                        <i class="bi bi-trash-fill"></i>
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
      </div>

      <div class="col-lg-4">
        <div class="card p-4 border-0 shadow-sm sticky-top rounded-4" style="top: 100px;">
            <h3 class="mb-3">Summary</h3>
            <div class="d-flex justify-content-between mb-4 pb-3 border-bottom">
                <span class="h5">Total</span>
                <span class="h4 text-danger">₱<?= number_format($grandTotal, 2) ?></span>
            </div>

            <?php if (!empty($cart)): ?>
                <form action="place_order.php" method="POST" id="checkoutForm">
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold"><i class="bi bi-pencil-fill text-warning me-2"></i>Special Instructions</label>
                        <textarea name="custom_instructions" class="form-control bg-light border-0 shadow-sm" rows="2" placeholder="E.g., No onions..."></textarea>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold"><i class="bi bi-geo-alt-fill text-danger me-2"></i>Delivery Address</label>
                        <textarea name="delivery_address" class="form-control bg-light border-0 shadow-sm" rows="3" required><?= htmlspecialchars($userAddress) ?></textarea>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold mb-3"><i class="bi bi-wallet2 text-success me-2"></i>Payment Method</label>
                        
                        <div class="payment-card active" id="cod-card">
                            <div class="d-flex align-items-center">
                                <div class="payment-icon bg-success-subtle text-success me-3"><i class="bi bi-cash-stack"></i></div>
                                <div class="flex-grow-1">
                                    <h5 class="mb-1 fw-bold">Cash on Delivery</h5>
                                    <small class="text-muted">Pay with cash upon arrival</small>
                                </div>
                            </div>
                            <input type="radio" name="payment_method" value="COD" id="cod" checked style="display: none;">
                        </div>

                        <div class="payment-card" id="gcash-card">
                            <div class="d-flex align-items-center">
                                <div class="payment-icon bg-primary-subtle text-primary me-3"><i class="bi bi-phone-fill"></i></div>
                                <div class="flex-grow-1">
                                    <h5 class="mb-1 fw-bold">GCash</h5>
                                    <small class="text-muted">Pay via GCash wallet</small>
                                </div>
                            </div>
                            <input type="radio" name="payment_method" value="GCash" id="gcash" style="display: none;">
                        </div>

                        <div class="gcash-box" id="gcash-details">
                            <h6 class="text-primary fw-bold mb-3 text-center">GCash Instructions</h6>
                            <div class="text-center mb-3">
                                <h4 class="text-primary fw-bold mb-0">0917-123-4567</h4>
                                <small class="text-muted">Pizza Hut Official</small>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold small">GCash Number <span class="text-danger">*</span></label>
                                <input type="text" inputmode="numeric" maxlength="11" name="gcash_number" id="gcash_number" class="form-control border-0 shadow-sm" placeholder="09xxxxxxxxx">
                            </div>
                            <div>
                                <label class="form-label fw-bold small">Ref Number <span class="text-danger">*</span></label>
                                <input type="text" name="gcash_ref" id="gcash_ref" class="form-control border-0 shadow-sm" placeholder="Ref No.">
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-danger w-100 py-3 rounded-pill fw-bold shadow-sm">
                        <i class="bi bi-check-circle-fill me-2"></i>Place Order Now
                    </button>
                </form>
            <?php else: ?>
                 <button class="btn btn-secondary w-100 py-2 rounded-pill" disabled>Cart is Empty</button>
            <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="confirmOrderModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content glass-modal"> 
        
        <div class="modal-header border-0">
          <h5 class="modal-title fw-bold"><i class="bi bi-receipt me-2"></i>Review Your Order</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body p-4">
          <div class="mb-3">
              <label class="small text-muted text-uppercase fw-bold">Delivery Address</label>
              <p id="modal-address" class="fw-semibold mb-0 text-dark"></p>
          </div>

          <div class="mb-3">
              <label class="small text-muted text-uppercase fw-bold">Payment Method</label>
              <p id="modal-payment" class="fw-semibold mb-0 text-danger"></p>
          </div>
          
          <hr class="opacity-25">
          
          <div class="d-flex justify-content-between align-items-center">
              <span class="fs-5">Total Amount:</span>
              <span id="modal-total" class="fs-3 fw-bold text-danger"></span>
          </div>
        </div>

        <div class="modal-footer border-0 justify-content-between">
          <button type="button" class="btn btn-light rounded-pill px-4 fw-bold border" data-bs-dismiss="modal">
              <i class="bi bi-arrow-left me-1"></i> Add More
          </button>
          
          <button type="button" class="btn btn-danger rounded-pill px-4 fw-bold shadow-sm" id="realSubmitBtn">
              Confirm & Place Order <i class="bi bi-check-lg ms-1"></i>
          </button>
        </div>

      </div>
    </div>
  </div>
  <?php include 'footer.php'; ?>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Elements
        const codCard = document.getElementById('cod-card');
        const gcashCard = document.getElementById('gcash-card');
        const gcashDetails = document.getElementById('gcash-details');
        const codRadio = document.getElementById('cod');
        const gcashRadio = document.getElementById('gcash');
        const gcashNumber = document.getElementById('gcash_number');
        const gcashRef = document.getElementById('gcash_ref');
        const checkoutForm = document.getElementById('checkoutForm');
        
        // Init Modal
        let modal = null;
        if(document.getElementById('confirmOrderModal')) {
            modal = new bootstrap.Modal(document.getElementById('confirmOrderModal'));
        }

        // Toggle Payment Method
        codCard.addEventListener('click', function() {
            codCard.classList.add('active');
            gcashCard.classList.remove('active');
            codRadio.checked = true;
            gcashDetails.classList.remove('show');
            if(gcashNumber) gcashNumber.removeAttribute('required');
            if(gcashRef) gcashRef.removeAttribute('required');
        });

        gcashCard.addEventListener('click', function() {
            gcashCard.classList.add('active');
            codCard.classList.remove('active');
            gcashRadio.checked = true;
            gcashDetails.classList.add('show');
            if(gcashNumber) gcashNumber.setAttribute('required', 'required');
            if(gcashRef) gcashRef.setAttribute('required', 'required');
        });

        if(gcashNumber) {
            gcashNumber.addEventListener('input', function(e) {
                this.value = this.value.replace(/[^0-9]/g, '');
            });
        }

        // INTERCEPT SUBMIT -> SHOW MODAL
        if(checkoutForm) {
            checkoutForm.addEventListener('submit', function(e) {
                e.preventDefault(); 

                // Validate GCash
                if (gcashRadio.checked) {
                    const number = gcashNumber.value;
                    const phMobilePattern = /^09\d{9}$/;
                    if (!phMobilePattern.test(number)) {
                        alert("Invalid GCash Number! Must be 09 + 9 digits.");
                        gcashNumber.focus();
                        return false;
                    }
                }

                // Fill Modal
                const address = document.querySelector('[name="delivery_address"]').value;
                const payment = codRadio.checked ? 'Cash on Delivery' : 'GCash (' + gcashNumber.value + ')';
                const totalText = document.querySelector('.h4.text-danger').innerText;

                document.getElementById('modal-address').innerText = address;
                document.getElementById('modal-payment').innerText = payment;
                document.getElementById('modal-total').innerText = totalText;

                // Show Modal
                if(modal) modal.show();
            });
        }

        // REAL SUBMIT
        const realSubmitBtn = document.getElementById('realSubmitBtn');
        if(realSubmitBtn) {
            realSubmitBtn.addEventListener('click', function() {
                checkoutForm.submit();
            });
        }

        // Remove Item
        document.querySelectorAll('.remove-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                if(!confirm("Remove item?")) return;
                let id = this.dataset.pizzaId;
                fetch('remove_from_cart.php', {
                    method: 'POST',
                    headers: {'Content-Type':'application/x-www-form-urlencoded'},
                    body: 'pizza_id='+id
                }).then(r=>r.json()).then(d=>{ if(d.success) location.reload(); });
            });
        });
    });
  </script>
</body>
</html>