<?php
session_start();
include 'db.php';

// 1. SECURITY CHECK & USER ID (MUST BE AT THE TOP)
if (!isset($_SESSION['user_id'])) {
    header("Location: main.php");
    exit;
}

$userId = $_SESSION['user_id'];
$isAdmin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;
$successMessage = '';
$errorMessage = '';

// --- 2. HANDLE ORDER CANCELLATION ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_order_group'])) {
    $groupId = $_POST['group_id'];
    
    // Only allow cancellation if status is 'pending'
    $stmt = $conn->prepare("UPDATE orders SET status = 'cancelled' WHERE order_group_id = ? AND user_id = ? AND status = 'pending'");
    $stmt->bind_param("si", $groupId, $userId);
    
    if ($stmt->execute() && $stmt->affected_rows > 0) {
        echo "<script>alert('Order successfully cancelled.'); window.location='profile.php';</script>";
    } else {
        echo "<script>alert('Cannot cancel this order. It may be already preparing or delivered.'); window.location='profile.php';</script>";
    }
    $stmt->close();
}

// --- 3. HANDLE REMOVE PROFILE PICTURE ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_picture'])) {
    $stmt = $conn->prepare("UPDATE users SET profile_image = NULL WHERE id = ?");
    $stmt->bind_param("i", $userId);
    
    if ($stmt->execute()) {
        $_SESSION['profile_image'] = null;
        $successMessage = "Profile picture removed successfully!";
    }
    $stmt->close();
}

// --- 4. HANDLE PROFILE UPDATE ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['update_profile']) || !empty($_FILES['profile_img']['name']))) {
    $newUsername = $_POST['username'];
    $newAddress = $_POST['address'];
    
    // Check for existing image
    $q = $conn->prepare("SELECT profile_image FROM users WHERE id = ?");
    $q->bind_param("i", $userId);
    $q->execute();
    $currentImg = $q->get_result()->fetch_assoc()['profile_image'];
    $imagePath = $currentImg;

    // Handle File Upload
    if (!empty($_FILES['profile_img']['name'])) {
        $targetDir = "uploads/";
        if (!is_dir($targetDir)) mkdir($targetDir);
        
        $fileName = $userId . '_' . time() . '_' . basename($_FILES["profile_img"]["name"]);
        $targetFilePath = $targetDir . $fileName;
        $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
        
        if(in_array($fileType, ['jpg','png','jpeg','gif'])){
            if(move_uploaded_file($_FILES["profile_img"]["tmp_name"], $targetFilePath)){
                $imagePath = $fileName;
            }
        }
    }
    
    // Update DB
    $stmt = $conn->prepare("UPDATE users SET username = ?, address = ?, profile_image = ? WHERE id = ?");
    $stmt->bind_param("sssi", $newUsername, $newAddress, $imagePath, $userId);
    
    if ($stmt->execute()) {
        $_SESSION['username'] = $newUsername; 
        $_SESSION['profile_image'] = $imagePath; 
        $successMessage = "Profile updated successfully!";
    } else {
        $errorMessage = "Error updating profile.";
    }
    $stmt->close();
}

// --- 5. FETCH USER DETAILS ---
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | Pizza Hut</title>
    <link rel="icon" href="icon.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Chewy&family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        body { font-family: 'Poppins', sans-serif; background: #f8f9fa; }
        h1, h3, h4, h5 { font-family: 'Chewy', cursive; }
        
        .admin-link {
            display: block; padding: 20px; border-radius: 15px;
            text-decoration: none; color: #333; background: white;
            transition: transform 0.2s, box-shadow 0.2s; border: 1px solid #eee; height: 100%;
        }
        .admin-link:hover {
            transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            border-color: #ffca28; background: #fffdf5;
        }
        .admin-icon { font-size: 2rem; margin-bottom: 10px; display: block; }
        
        .custom-toast { position: fixed; top: 20px; right: 20px; z-index: 1055; }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    
    <?php include 'navbar.php'; ?>

    <div class="custom-toast">
        <?php if($successMessage): ?>
            <div class="toast show bg-success text-white border-0 shadow" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body"><i class="bi bi-check-circle me-2"></i><?= $successMessage ?></div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            </div>
        <?php endif; ?>
        <?php if($errorMessage): ?>
            <div class="toast show bg-danger text-white border-0 shadow" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body"><i class="bi bi-exclamation-circle me-2"></i><?= $errorMessage ?></div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="container py-5 flex-grow-1">
        <div class="row g-4">
            
            <div class="col-md-4">
                <div class="card border-0 shadow-sm p-4 text-center h-100">
                    
                    <form method="POST" enctype="multipart/form-data" class="text-start mt-4" id="profileForm">
                        <input type="hidden" name="update_profile" value="1">

                        <div class="position-relative mx-auto mb-3 text-center" style="width: 100px;">
                            <?php if (!empty($user['profile_image']) && file_exists("uploads/" . $user['profile_image'])): ?>
                                <img src="uploads/<?= $user['profile_image'] ?>" 
                                     class="rounded-circle object-fit-cover shadow-sm border" 
                                     style="width: 100px; height: 100px;" id="profilePreview">
                                
                                <button type="submit" name="remove_picture" formnovalidate class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger border border-light p-1" style="cursor: pointer; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center;" title="Remove Photo">
                                    <i class="bi bi-x"></i>
                                </button>
                            <?php else: ?>
                                <div class="bg-danger text-white rounded-circle d-flex align-items-center justify-content-center mx-auto" style="width: 100px; height: 100px; font-size: 2.5rem;">
                                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                                </div>
                            <?php endif; ?>

                            <label for="p_img" class="position-absolute bottom-0 start-50 translate-middle-x mb-n2 btn btn-light btn-sm rounded-circle border shadow-sm" style="cursor: pointer;" title="Upload Photo">
                                <i class="bi bi-camera-fill text-dark"></i>
                            </label>

                            <input type="file" name="profile_img" id="p_img" style="display:none;" accept="image/*">
                        </div>
                        
                        <h3 class="text-center"><?= htmlspecialchars($user['username']) ?></h3>
                        <p class="text-muted small mb-4 text-center"><?= htmlspecialchars($user['email']) ?></p>
                        
                        <hr>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold small text-uppercase">Display Name</label>
                            <input type="text" name="username" class="form-control bg-light" value="<?= htmlspecialchars($user['username']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold small text-uppercase">Default Address</label>
                            <textarea name="address" class="form-control bg-light" rows="3" required><?= htmlspecialchars($user['address']) ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-dark w-100 fw-bold">Update Info</button>
                    </form>
                    
                    <div class="mt-3">
                        <a href="logout.php" class="btn btn-outline-danger w-100 btn-sm">Sign Out</a>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <?php if ($isAdmin): ?>
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header bg-dark text-white py-3">
                            <h4 class="mb-0"><i class="bi bi-speedometer2 text-warning me-2"></i> Management Console</h4>
                        </div>
                        <div class="card-body p-4">
                            <div class="alert alert-success border-0 d-flex align-items-center shadow-sm" style="background-color: #e8f5e9; color: #1b5e20;">
                                <i class="bi bi-stars me-3 fs-3"></i>
                                <div>
                                    <strong class="fs-5">Welcome back, Administrator.</strong> <br>
                                    Here is your command center.
                                </div>
                            </div>
                            <h5 class="mt-4 mb-3 text-muted border-bottom pb-2">Quick Actions</h5>
                            <div class="row g-3">
                                <div class="col-sm-6"><a href="admin.php" class="admin-link text-center"><span class="admin-icon text-primary"><i class="bi bi-kanban"></i></span><span class="fw-bold d-block">Dashboard</span></a></div>
                                <div class="col-sm-6"><a href="admin.php#orders" class="admin-link text-center"><span class="admin-icon text-danger"><i class="bi bi-bell-fill"></i></span><span class="fw-bold d-block">Incoming Orders</span></a></div>
                                <div class="col-sm-6"><a href="add_pizza.php" class="admin-link text-center"><span class="admin-icon text-success"><i class="bi bi-plus-circle-fill"></i></span><span class="fw-bold d-block">Add New Item</span></a></div>
                                <div class="col-sm-6"><a href="admin.php#users" class="admin-link text-center"><span class="admin-icon text-warning"><i class="bi bi-people-fill"></i></span><span class="fw-bold d-block">Manage Users</span></a></div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                            <h4 class="mb-0 text-danger"><i class="bi bi-clock-history me-2"></i> My Order History</h4>
                            <a href="menu.php" class="btn btn-sm btn-danger rounded-pill px-3">Order Again</a>
                        </div>
                        
                        <div class="card-body p-0" id="order-history-container">
                            <div class="text-center py-5">
                                <div class="spinner-border text-danger" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <p class="mt-2 text-muted">Loading your orders...</p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="modal fade" id="cropModal" tabindex="-1" data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Adjust Profile Picture</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-0">
                    <div class="img-container" style="max-height: 500px;">
                        <img id="cropImage" src="" style="max-width: 100%; display: block;">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="cropBtn">Save & Update</button>
                </div>
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // ... (Keep your existing Cropper logic here) ...
        const fileInput = document.getElementById('p_img');
        const cropModal = new bootstrap.Modal(document.getElementById('cropModal'));
        const cropImage = document.getElementById('cropImage');
        let cropper;

        fileInput.addEventListener('change', function(e) {
            if (e.target.files && e.target.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    cropImage.src = e.target.result;
                    cropModal.show();
                    if(cropper) cropper.destroy();
                    // Small delay to ensure modal is visible
                    setTimeout(() => {
                        cropper = new Cropper(cropImage, {
                            aspectRatio: 1,
                            viewMode: 1,
                            dragMode: 'move',
                            autoCropArea: 1,
                        });
                    }, 200);
                }
                reader.readAsDataURL(e.target.files[0]);
            }
        });

        document.getElementById('cropBtn').addEventListener('click', function() {
            if(cropper) {
                const canvas = cropper.getCroppedCanvas({
                    width: 300, height: 300
                });
                
                canvas.toBlob(function(blob) {
                    const formData = new FormData(document.getElementById('profileForm'));
                    formData.set('profile_img', blob, 'profile.jpg');
                    
                    fetch('profile.php', {
                        method: 'POST',
                        body: formData
                    }).then(() => {
                        location.reload();
                    });
                });
            }
        });
        
        // Auto-hide toast
        setTimeout(() => {
            document.querySelectorAll('.custom-toast .toast').forEach(toast => {
                toast.classList.remove('show');
            });
        }, 5000);
        
        <?php if (!$isAdmin): ?>
        function loadOrderHistory() {
            fetch('fetch_orders.php')
                .then(response => response.text())
                .then(html => {
                    const container = document.getElementById('order-history-container');
                    if (container.innerHTML !== html) {
                        container.innerHTML = html;
                    }
                })
                .catch(err => console.error('Error loading orders:', err));
        }
        loadOrderHistory();
        setInterval(loadOrderHistory, 3000);
        <?php endif; ?>
    </script>
</body>
</html>