<?php
session_start();
include 'db.php';

$message = '';
$messageType = '';
$tokenValid = false;
$email = '';

if (isset($_GET['token'])) {
    $token = $_GET['token'];
    
    $stmt = $conn->prepare("SELECT email, reset_expiry FROM users WHERE reset_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $expiry = strtotime($user['reset_expiry']);
        
        if ($expiry > time()) {
            $tokenValid = true;
            $email = $user['email'];
        } else {
            $message = "This reset link has expired.";
            $messageType = 'warning';
        }
    } else {
        $message = "Invalid reset link.";
        $messageType = 'danger';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_password'])) {
    $token = $_POST['token'];
    $newPassword = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];
    
    if (strlen($newPassword) < 8) {
        $message = "Password must be at least 8 characters.";
        $messageType = 'danger';
        $tokenValid = true;
    } elseif ($newPassword !== $confirmPassword) {
        $message = "Passwords do not match.";
        $messageType = 'danger';
        $tokenValid = true;
    } else {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expiry = NULL WHERE reset_token = ?");
        $stmt->bind_param("ss", $hashedPassword, $token);
        
        if ($stmt->execute()) {
            $message = "Password reset successful! You can now login.";
            $messageType = 'success';
            $tokenValid = false;
        } else {
            $message = "Something went wrong. Please try again.";
            $messageType = 'danger';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | Pizza Hut</title>
    <link rel="icon" href="icon.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Chewy&family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        body { 
            font-family: 'Poppins', sans-serif; 
            background: #f4f4f4; 
            min-height: 100vh;
            display: flex; align-items: center; justify-content: center;
        }
        h1, h2, h3 { font-family: 'Chewy', cursive; }
        
        .auth-card {
            border: none; border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            overflow: hidden; max-width: 450px; width: 100%;
        }
        .auth-header {
            background: #d32f2f; padding: 30px;
            text-align: center; color: white;
        }
        .icon-circle {
            width: 80px; height: 80px; background: rgba(255,255,255,0.2);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            margin: 0 auto 15px; font-size: 2.5rem;
        }
        .form-control {
            border-radius: 10px; padding: 12px 15px; border: 1px solid #eee; background: #f8f9fa;
        }
        .form-control:focus { box-shadow: none; border-color: #d32f2f; background: white; }
        
        .btn-pizza {
            background: #d32f2f; color: white; border: none;
            border-radius: 50px; padding: 12px; font-weight: bold; transition: all 0.3s;
        }
        .btn-pizza:hover { background: #b71c1c; transform: translateY(-2px); color: white; }
        
        /* Password Strength Meter */
        .strength-meter { height: 4px; background: #eee; margin-top: 8px; border-radius: 2px; overflow: hidden; display: flex; }
        .strength-bar { height: 100%; width: 0; transition: all 0.3s; }
        .weak { width: 33%; background: #dc3545; }
        .medium { width: 66%; background: #ffc107; }
        .strong { width: 100%; background: #198754; }
    </style>
</head>
<body>

    <div class="container p-3">
        <div class="auth-card mx-auto bg-white">
            
            <div class="auth-header">
                <div class="icon-circle"><i class="bi bi-shield-lock-fill"></i></div>
                <h2 class="mb-0">Set New Password</h2>
            </div>
            
            <div class="p-4 p-md-5">
                <?php if ($message): ?>
                    <div class="alert alert-<?= $messageType ?> rounded-3 border-0 shadow-sm mb-4 text-center">
                        <?= $message ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($tokenValid): ?>
                    <form method="POST" id="resetForm">
                        <input type="hidden" name="token" value="<?= htmlspecialchars($_GET['token']) ?>">
                        <input type="hidden" name="reset_password" value="1">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold text-muted small text-uppercase">New Password</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-0 rounded-start-3 ps-3"><i class="bi bi-lock text-danger"></i></span>
                                <input type="password" name="password" id="newPassword" class="form-control border-0 bg-light" required minlength="8">
                            </div>
                            <div class="strength-meter"><div id="strengthBar" class="strength-bar"></div></div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-bold text-muted small text-uppercase">Confirm Password</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-0 rounded-start-3 ps-3"><i class="bi bi-check-lg text-danger"></i></span>
                                <input type="password" name="confirm_password" id="confirmPassword" class="form-control border-0 bg-light" required>
                            </div>
                            <div id="matchMessage" class="form-text mt-1 small"></div>
                        </div>
                        
                        <button type="submit" class="btn btn-pizza w-100 mb-3 shadow-sm">Update Password</button>
                        
                        <div class="text-center mt-3 pt-2 border-top">
                            <a href="main.php" class="text-decoration-none text-muted small fw-bold">
                                <i class="bi bi-house-door-fill me-1 text-danger"></i> Return to Website
                            </a>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="text-center">
                        <a href="main.php" class="btn btn-pizza w-100 shadow-sm mb-3">Go to Login</a>
                        <a href="main.php" class="text-decoration-none text-muted">Return to Website</a>
                    </div>
                <?php endif; ?>
            </div>
            
        </div>
    </div>
    
    <script>
        const newPass = document.getElementById('newPassword');
        const confirmPass = document.getElementById('confirmPassword');
        const bar = document.getElementById('strengthBar');
        const matchMsg = document.getElementById('matchMessage');
        
        if(newPass) {
            newPass.addEventListener('input', function() {
                const val = this.value;
                let score = 0;
                if(val.length > 5) score++;
                if(val.length > 8) score++;
                if(/[A-Z]/.test(val)) score++;
                if(/[0-9]/.test(val)) score++;
                
                bar.className = 'strength-bar';
                if(val.length > 0) {
                    if(score <= 2) bar.classList.add('weak');
                    else if(score === 3) bar.classList.add('medium');
                    else bar.classList.add('strong');
                }
            });
        }
        
        if(confirmPass) {
            confirmPass.addEventListener('input', function() {
                if(this.value === newPass.value && this.value !== '') {
                    matchMsg.innerHTML = '<span class="text-success fw-bold"><i class="bi bi-check"></i> Passwords match</span>';
                } else {
                    matchMsg.innerHTML = '<span class="text-danger"><i class="bi bi-x"></i> Passwords do not match</span>';
                }
            });
        }
    </script>
</body>
</html>