<?php
session_start();
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'You must be logged in.']);
    exit;
}

// Check for required input
$pizzaId = $_POST['pizza_id'] ?? null;
if (!$pizzaId || !is_numeric($pizzaId)) {
    echo json_encode(['success' => false, 'message' => 'Invalid pizza ID provided.']);
    exit;
}

// Get the cart from the session
$cart = $_SESSION['cart'] ?? [];

// Check if the item exists in the cart
if (isset($cart[$pizzaId])) {
    // Remove the item from the cart
    unset($cart[$pizzaId]);

    // Update the session cart
    $_SESSION['cart'] = $cart;

    echo json_encode(['success' => true, 'message' => 'Item removed from cart.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Item was not found in cart.']);
}
?>