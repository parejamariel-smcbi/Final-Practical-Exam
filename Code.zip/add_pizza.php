<?php
session_start();
include 'db.php';

// Admin Check
if (!isset($_SESSION['user_id']) || empty($_SESSION['is_admin'])) {
    header("Location: main.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $category = $_POST['category']; // <--- We use this now
    
    // Handle File Upload
    if (!empty($_FILES['image']['name'])) {
        $fileInfo = pathinfo($_FILES['image']['name']);
        $extension = strtolower($fileInfo['extension']);
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (!in_array($extension, $allowedExtensions)) {
            echo "<script>alert('Error: Only images allowed.'); window.location='add_pizza.php';</script>";
            exit;
        }

        $uniqueName = uniqid() . '.' . $extension;
        $target = "uploads/" . $uniqueName;
        
        if (!is_dir('uploads')) mkdir('uploads');

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            $image = "uploads/" . $uniqueName;
        } else {
            echo "<script>alert('Error uploading file.'); window.location='add_pizza.php';</script>";
            exit;
        }
    } else {
        $image = "images/default.png"; 
    }

    // INSERT with Category
    $stmt = $conn->prepare("INSERT INTO pizzas (name, description, price, image, category) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdss", $name, $description, $price, $image, $category);
    
    if ($stmt->execute()) {
        echo "<script>alert('Item added successfully!'); window.location='admin.php';</script>";
    } else {
        echo "Database error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Item | Admin</title>
    <link rel="icon" href="icon.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>body { font-family: 'Poppins', sans-serif; background: #f4f6f9; }</style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-sm border-0 rounded-4">
                    <div class="card-header bg-danger text-white text-center py-3 rounded-top-4">
                        <h4 class="mb-0">Add New Menu Item</h4>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" enctype="multipart/form-data">
                            
                            <div class="mb-3">
                                <label class="form-label fw-bold">Item Name</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Category</label>
                                <select name="category" class="form-select" required>
                                    <option value="pizza">🍕 Pizza</option>
                                    <option value="drinks">🍹 Drinks</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Description</label>
                                <textarea name="description" class="form-control" rows="3" required></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-bold">Price (₱)</label>
                                <input type="number" step="0.01" name="price" class="form-control" required>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-bold">Image</label>
                                <input type="file" name="image" class="form-control" accept="image/*" required>
                            </div>

                            <button type="submit" class="btn btn-danger w-100 fw-bold">Add to Menu</button>
                            <a href="admin.php" class="btn btn-outline-secondary w-100 mt-2">Cancel</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>