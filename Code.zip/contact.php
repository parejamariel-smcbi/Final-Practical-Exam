<?php
session_start();
$isLoggedIn = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Contact Us | Pizza Hut</title>
  <link rel="icon" href="icon.png" type="image/png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Chewy&family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  
  <style>
    body { font-family: 'Poppins', sans-serif; background-color: #f9f9f9; }
    h1, h2 { font-family: 'Chewy', cursive; }
    .contact-box { background: white; border-radius: 20px; padding: 40px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }
    .icon-box { width: 60px; height: 60px; background: #ffebee; color: #d32f2f; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; margin-bottom: 20px; }
  </style>
</head>
<body>

  <?php include 'navbar.php'; ?>

  <div class="container py-5">
    <div class="text-center mb-5">
        <h1 class="text-danger display-4">Get in Touch</h1>
        <p class="lead text-muted">We'd love to hear from you. Here's how you can reach us.</p>
    </div>

    <div class="row g-4 justify-content-center">
        <div class="col-md-4">
            <div class="contact-box text-center h-100">
                <div class="icon-box mx-auto"><i class="bi bi-geo-alt-fill"></i></div>
                <h4>Visit Us</h4>
                <p class="text-muted">Managa, Bansalan<br>Davao Del Sur, Philippines</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="contact-box text-center h-100">
                <div class="icon-box mx-auto"><i class="bi bi-telephone-fill"></i></div>
                <h4>Call Us</h4>
                <p class="text-muted">+63 912 345 6789<br>Mon-Sun, 9AM - 10PM</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="contact-box text-center h-100">
                <div class="icon-box mx-auto"><i class="bi bi-envelope-fill"></i></div>
                <h4>Email Us</h4>
                <p class="text-muted">hello@pizzahut.com<br>support@pizzahut.com</p>
            </div>
        </div>
    </div>

    <div class="row mt-5">
        <div class="col-12">
            <div class="contact-box p-2">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3962.3456789!2d125.0!3d6.0!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNsKwNTAnMDAuMCJOIDEyNcKwMDAnMDAuMCJF!5e0!3m2!1sen!2sph!4v1600000000000!5m2!1sen!2sph" width="100%" height="400" style="border:0; border-radius: 15px;" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>
    </div>
  </div>

  <?php include 'footer.php'; ?> <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>