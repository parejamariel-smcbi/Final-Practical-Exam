<?php
// Hostinger Database Connection Details
$servername = "localhost";
$username = "u983768004_pizzahut";
$password = "Hatenako913";
$dbname = "u983768004_pizza_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    // CRITICAL: Force a prominent output to bypass generic server error
    echo "<h1>❌ FATAL ERROR: Database Connection Failed!</h1>";
    echo "<p>Please verify credentials in db.php. Error Detail: " . $conn->connect_error . "</p>";
    exit; // Stop all further script execution
}

$conn->set_charset("utf8mb4");
?>