<?php
date_default_timezone_set('Asia/Manila');
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || empty($_SESSION['is_admin'])) exit;
header('Content-Type: application/json');

// 1. Data Calculations
$today = date('Y-m-d');
$eQ = $conn->query("SELECT SUM(total_price) as t FROM orders WHERE DATE(order_date)='$today' AND status NOT IN ('cancelled','refunded')");
$todayEarn = $eQ->fetch_assoc()['t'] ?? 0;

$oQ = $conn->query("SELECT COUNT(DISTINCT order_group_id) as t FROM orders");
$totalOrders = $oQ->fetch_assoc()['t'] ?? 0;

$graph = [];
for ($i=6; $i>=0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $gQ = $conn->query("SELECT SUM(total_price) as t FROM orders WHERE DATE(order_date)='$d' AND status NOT IN ('cancelled','refunded')");
    $graph[] = ['day'=>date('D', strtotime($d)), 'date'=>$d, 'amount'=>floatval($gQ->fetch_assoc()['t'] ?? 0)];
}

// 2. Build Table HTML with NEW COLORS
$html = '';
$res = $conn->query("SELECT * FROM orders GROUP BY order_group_id ORDER BY order_date DESC LIMIT 10");

if ($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
        $s = $row['status'];
        
        // --- FIXED COLOR PALETTE ---
        $badge = 'bg-warning text-dark'; // Pending (Yellow)
        if($s=='preparing') $badge = 'bg-dark text-white'; // Kitchen (Black)
        if($s=='delivered') $badge = 'bg-success'; // Done (Green)
        if($s=='cancelled') $badge = 'bg-secondary'; // Cancelled (Gray)
        if($s=='refunded')  $badge = 'bg-dark opacity-50'; // Refunded (Faded Black)

        // User
        $uName = "Guest";
        $uQ = $conn->query("SELECT username FROM users WHERE id=".$row['user_id']);
        if($uQ && $u = $uQ->fetch_assoc()) $uName = $u['username'];

        $html .= '<tr>';
        $html .= '<td class="fw-bold">#'.substr($row['order_group_id'],0,8).'</td>';
        $html .= '<td>'.htmlspecialchars($uName).'</td>';
        $html .= '<td><span class="badge rounded-pill '.$badge.'">'.ucfirst($s).'</span></td>';
        $html .= '<td><div class="fw-bold">₱'.number_format($row['total_price'],2).'</div><div class="small text-muted">'.ucfirst($row['payment_method']).'</div></td>';
        
        // Action
        $html .= '<td>
            <form method="POST" class="d-inline me-1">
                <input type="hidden" name="order_group_id" value="'.$row['order_group_id'].'">
                <input type="hidden" name="update_order_status" value="1">
                <select name="status" class="form-select form-select-sm d-inline-block border-secondary" style="width:100px" onchange="this.form.submit()">
                    <option value="pending" '.($s=='pending'?'selected':'').'>Pending</option>
                    <option value="preparing" '.($s=='preparing'?'selected':'').'>Kitchen</option>
                    <option value="delivered" '.($s=='delivered'?'selected':'').'>Delivered</option>
                    <option value="cancelled" '.($s=='cancelled'?'selected':'').'>Cancel</option>
                    <option value="refunded" '.($s=='refunded'?'selected':'').'>Refunded</option>
                </select>
            </form>
            <form method="POST" class="d-inline" onsubmit="return confirm(\'Delete?\');">
                <input type="hidden" name="order_group_id" value="'.$row['order_group_id'].'">
                <input type="hidden" name="delete_order" value="1">
                <button class="btn btn-sm btn-outline-dark"><i class="bi bi-trash"></i></button>
            </form>
        </td>';
        $html .= '</tr>';
    }
} else {
    $html = '<tr><td colspan="5" class="text-center py-4 text-muted">No orders found</td></tr>';
}

echo json_encode(['today_earnings'=>$todayEarn, 'total_orders'=>$totalOrders, 'last_7_days'=>$graph, 'orders_html'=>$html]);
?>