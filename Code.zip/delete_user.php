<?php
session_start();
include 'db.php';

// 🔐 Security: Admin Only
if (!isset($_SESSION['user_id']) || empty($_SESSION['is_admin'])) {
    header("Location: main.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'])) {
        $userId = $_POST['user_id'];

    // 1. Prevent deleting yourself
    if ($userId == $_SESSION['user_id']) {
        echo "<script>alert('You cannot delete your own admin account!'); window.location='admin.php';</script>";
        exit;
    }

    // 2. Delete User's Orders first (Required for MyISAM db engine)
    $orderStmt = $conn->prepare("DELETE FROM orders WHERE user_id = ?");
    $orderStmt->bind_param("i", $userId);
    $orderStmt->execute();
    $orderStmt->close();

    // 3. Delete User Account
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();


header("Location: admin.php");
exit;
?>