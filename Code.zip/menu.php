<?php
session_start();
include 'db.php'; 
$isLoggedIn = isset($_SESSION['user_id']);

// Fetch Items and separate them
$pizzas = [];
$drinks = [];

// List of words that identify a drink (Since we removed the category column)
$drinkKeywords = ['coke', 'sprite', 'royal', 'pepsi', 'mountain dew', 'water', 'juice', 'tea', 'coffee', 'drink'];

if ($conn) {
    // REMOVED 'category' from SELECT query because it no longer exists in DB
    $sql = "SELECT id, name, description, price, image, is_available FROM pizzas ORDER BY id ASC";
    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $isDrink = false;
            $nameLower = strtolower($row['name']);

            // Check if the name contains any drink keyword
            foreach ($drinkKeywords as $keyword) {
                if (strpos($nameLower, $keyword) !== false) {
                    $isDrink = true;
                    break;
                }
            }

            if ($isDrink) {
                $drinks[] = $row;
            } else {
                $pizzas[] = $row;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Our Menu | Pizza Hut</title>
    <link rel="icon" href="icon.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Chewy&family=Poppins:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
      body { font-family: 'Poppins', sans-serif; background-color: #f4f4f4; }
      h1, h2, h5 { font-family: 'Chewy', cursive; }
      
      .menu-section-title {
          font-size: 2.5rem;
          color: #333;
          margin-bottom: 30px;
          border-bottom: 3px solid #ffca28;
          display: inline-block;
          padding-bottom: 5px;
      }
      
      .pizza-card {
          border: none;
          border-radius: 20px;
          overflow: hidden;
          transition: transform 0.3s ease, box-shadow 0.3s ease;
          background: white;
          height: 100%;
          position: relative;
      }
      .pizza-card:hover {
          transform: translateY(-10px);
          box-shadow: 0 15px 30px rgba(0,0,0,0.1);
      }
      
      /* OUT OF STOCK OVERLAY */
      .pizza-card.out-of-stock {
          opacity: 0.7;
          position: relative;
      }
      
      .pizza-card.out-of-stock::after {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0, 0, 0, 0.5);
          z-index: 1;
          pointer-events: none;
      }
      
      .pizza-card.out-of-stock .card-img-top {
          filter: grayscale(100%);
      }
      
      .out-of-stock-badge {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%) rotate(-15deg);
          background: #dc3545;
          color: white;
          padding: 15px 30px;
          font-size: 1.5rem;
          font-weight: bold;
          border-radius: 10px;
          z-index: 2;
          box-shadow: 0 10px 30px rgba(220, 53, 69, 0.5);
          border: 3px solid white;
      }
      
      .card-img-top {
          height: 250px;
          object-fit: cover;
      }
      .price-tag {
          font-size: 1.5rem;
          font-weight: 800;
          color: #d32f2f;
      }
      .badge-custom { position: absolute; top: 15px; left: 15px; font-size: 0.9rem; padding: 8px 15px; border-radius: 20px; z-index: 3; }
      .bg-bestseller { background-color: #ffc107; color: #000; }
      .bg-spicy { background-color: #d32f2f; color: #fff; }
      .bg-veggie { background-color: #4caf50; color: #fff; }
      .bg-drinks { background-color: #00bcd4; color: #fff; }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">

    <?php include 'navbar.php'; ?>

    <div class="container py-5 flex-grow-1">
        <div class="text-center mb-5">
            <h1 class="display-4 text-danger">Our Full Menu</h1>
            <p class="lead text-muted">From hot slices to cold sips.</p>
        </div>

        <div class="mb-5">
            <h2 class="menu-section-title"><i class="bi bi-fire text-danger"></i> Hot Pizzas</h2>
            <div class="row g-4">
                <?php if (empty($pizzas)): ?>
                    <div class="col-12 text-center"><h3>No pizzas available right now.</h3></div>
                <?php else: ?>
                    <?php foreach ($pizzas as $item): 
                        $isOutOfStock = empty($item['is_available']) || $item['is_available'] == 0;
                    ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="card pizza-card shadow-sm <?= $isOutOfStock ? 'out-of-stock' : '' ?>">
                                
                                <?php if ($isOutOfStock): ?>
                                    <div class="out-of-stock-badge">
                                        <i class="bi bi-x-circle me-2"></i>OUT OF STOCK
                                    </div>
                                <?php endif; ?>
                                
                                <img src="<?= htmlspecialchars($item['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($item['name']) ?>">
                                <div class="card-body d-flex flex-column">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h5 class="card-title fs-3 mb-0"><?= htmlspecialchars($item['name']) ?></h5>
                                        <span class="price-tag">₱<?= number_format($item['price'], 0) ?></span>
                                    </div>
                                    <p class="card-text text-muted flex-grow-1"><?= htmlspecialchars($item['description']) ?></p>
                                    <div class="mt-3">
                                            <?php if ($isLoggedIn): ?>
                                                <?php if(empty($_SESSION['is_admin'])): ?>
                                                    <?php if ($isOutOfStock): ?>
                                                        <button class="btn btn-secondary w-100 rounded-pill" disabled>
                                                            <i class="bi bi-x-circle me-2"></i> Currently Unavailable
                                                        </button>
                                                    <?php else: ?>
                                                        <form class="add-to-cart-form d-flex gap-2">
                                                            <input type="hidden" name="pizza_id" value="<?= $item['id'] ?>">
                                                            <input type="number" name="quantity" value="1" min="1" class="form-control rounded-pill text-center" style="width: 70px;">
                                                            <button type="submit" class="btn btn-danger rounded-pill flex-grow-1 fw-bold">
                                                                <i class="bi bi-cart-plus-fill me-2"></i> Add
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <button class="btn btn-secondary w-100 rounded-pill" disabled>Admin Mode</button>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <?php if ($isOutOfStock): ?>
                                                    <button class="btn btn-secondary w-100 rounded-pill" disabled>
                                                        <i class="bi bi-x-circle me-2"></i> Currently Unavailable
                                                    </button>
                                                <?php else: ?>
                                                    <button class="btn btn-outline-danger w-100 rounded-pill fw-bold" data-bs-toggle="modal" data-bs-target="#loginModal">Login to Order</button>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="mb-5">
            <h2 class="menu-section-title"><i class="bi bi-cup-straw text-info"></i> Ice Cold Drinks</h2>
            <div class="row g-4">
                <?php if (empty($drinks)): ?>
                    <div class="col-12 text-center"><h3>No drinks available right now.</h3></div>
                <?php else: ?>
                    <?php foreach ($drinks as $item): 
                        $isOutOfStock = empty($item['is_available']) || $item['is_available'] == 0;
                    ?>
                         <div class="col-md-6 col-lg-4">
                            <div class="card pizza-card shadow-sm <?= $isOutOfStock ? 'out-of-stock' : '' ?>">
                                <span class="badge badge-custom bg-drinks">🍹 Drink</span>
                                
                                <?php if ($isOutOfStock): ?>
                                    <div class="out-of-stock-badge">
                                        <i class="bi bi-x-circle me-2"></i>OUT OF STOCK
                                    </div>
                                <?php endif; ?>
                                
                                <img src="<?= htmlspecialchars($item['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($item['name']) ?>">
                                <div class="card-body d-flex flex-column">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h5 class="card-title fs-3 mb-0"><?= htmlspecialchars($item['name']) ?></h5>
                                        <span class="price-tag">₱<?= number_format($item['price'], 0) ?></span>
                                    </div>
                                    <p class="card-text text-muted flex-grow-1"><?= htmlspecialchars($item['description']) ?></p>
                                    <div class="mt-3">
                                            <?php if ($isLoggedIn): ?>
                                                <?php if(empty($_SESSION['is_admin'])): ?>
                                                    <?php if ($isOutOfStock): ?>
                                                        <button class="btn btn-secondary w-100 rounded-pill" disabled>
                                                            <i class="bi bi-x-circle me-2"></i> Currently Unavailable
                                                        </button>
                                                    <?php else: ?>
                                                        <form class="add-to-cart-form d-flex gap-2">
                                                            <input type="hidden" name="pizza_id" value="<?= $item['id'] ?>">
                                                            <input type="number" name="quantity" value="1" min="1" class="form-control rounded-pill text-center" style="width: 70px;">
                                                            <button type="submit" class="btn btn-danger rounded-pill flex-grow-1 fw-bold">
                                                                <i class="bi bi-cart-plus-fill me-2"></i> Add
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <button class="btn btn-secondary w-100 rounded-pill" disabled>Admin Mode</button>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <?php if ($isOutOfStock): ?>
                                                    <button class="btn btn-secondary w-100 rounded-pill" disabled>
                                                        <i class="bi bi-x-circle me-2"></i> Currently Unavailable
                                                    </button>
                                                <?php else: ?>
                                                    <button class="btn btn-outline-danger w-100 rounded-pill fw-bold" data-bs-toggle="modal" data-bs-target="#loginModal">Login to Order</button>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
        <div id="liveToast" class="toast align-items-center text-white bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body fw-bold" id="toastMessage">Item added to cart!</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Handle Add to Cart via AJAX
    document.querySelectorAll('.add-to-cart-form').forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            fetch('add_to_cart.php', { method: 'POST', body: new URLSearchParams(formData) })
            .then(response => response.json())
            .then(data => {
                const toastEl = document.getElementById('liveToast');
                const toastBody = document.getElementById('toastMessage');
                const toast = new bootstrap.Toast(toastEl);
                toastBody.innerText = data.message;
                if(data.success) {
                    toastEl.classList.remove('bg-danger'); toastEl.classList.add('bg-success');
                    setTimeout(() => location.reload(), 1000); 
                } else {
                    toastEl.classList.remove('bg-success'); toastEl.classList.add('bg-danger');
                }
                toast.show();
            });
        });
    });
    </script>
</body>
</html>