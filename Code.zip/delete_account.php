<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: main.php");
    exit;
}

$userId = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Delete User's Orders first (Constraint logic)
    $stmt = $conn->prepare("DELETE FROM orders WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->close();

    // 2. Delete User Account
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    
    if ($stmt->execute()) {
        // 3. Destroy Session & Redirect
        session_destroy();
        echo "<script>alert('Your account has been deleted.'); window.location='main.php';</script>";
    } else {
        echo "Error deleting account.";
    }
    $stmt->close();
} else {
    header("Location: profile.php");
}
?>