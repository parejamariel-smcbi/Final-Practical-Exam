<?php
session_start();
include 'db.php';

// 🔒 Security: Admin Only
if (!isset($_SESSION['user_id']) || empty($_SESSION['is_admin'])) {
    header("Location: main.php");
    exit;
}

// --- HANDLE ACTIONS ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update Status
    if (isset($_POST['update_order_status'])) {
        $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE order_group_id = ?");
        $stmt->bind_param("ss", $_POST['status'], $_POST['order_group_id']);
        $stmt->execute();
        header("Location: admin.php"); exit;
    }
    // Delete Order
    if (isset($_POST['delete_order'])) {
        $stmt = $conn->prepare("DELETE FROM orders WHERE order_group_id = ?");
        $stmt->bind_param("s", $_POST['order_group_id']);
        $stmt->execute();
        header("Location: admin.php"); exit;
    }
    // Toggle Stock
    if (isset($_POST['toggle_stock'])) {
        $newStatus = $_POST['current_status'] == 1 ? 0 : 1;
        $stmt = $conn->prepare("UPDATE pizzas SET is_available = ? WHERE id = ?");
        $stmt->bind_param("ii", $newStatus, $_POST['pizza_id']);
        $stmt->execute();
        header("Location: admin.php#pizzas"); exit;
    }
    // Delete Item
    if (isset($_POST['delete_pizza'])) {
        $stmt = $conn->prepare("DELETE FROM pizzas WHERE id = ?");
        $stmt->bind_param("i", $_POST['pizza_id']);
        $stmt->execute();
        header("Location: admin.php#pizzas"); exit;
    }
    // Delete User
    if (isset($_POST['delete_user'])) {
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $_POST['user_id']);
        $stmt->execute();
        header("Location: admin.php#users"); exit;
    }
}

$userResult = $conn->query("SELECT * FROM users");
$totalUsers = $userResult->num_rows;
$pizzaResult = $conn->query("SELECT * FROM pizzas ORDER BY id DESC");
$totalPizzas = $pizzaResult->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Pizza Hut</title>
    <link rel="icon" href="icon.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Chewy&family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        body { font-family: 'Poppins', sans-serif; background: #f8f9fa; }
        h1, h2, h3, h4, h5 { font-family: 'Chewy', cursive; }
        
        /* CARDS */
        .card { border: none; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .card-header { background: #212529; color: white; border-radius: 15px 15px 0 0 !important; }
        
        /* LINKS */
        .admin-link {
            display: block; padding: 20px; border-radius: 15px;
            text-decoration: none; color: #333; background: white;
            transition: all 0.2s ease; border: 1px solid #eee;
        }
        .admin-link:hover {
            transform: translateY(-5px);
            border-color: #dc3545;
            box-shadow: 0 10px 20px rgba(220, 53, 69, 0.15);
        }
        .admin-icon { font-size: 2.2rem; margin-bottom: 10px; display: block; color: #dc3545; }
        
        /* --- GRAPH STYLES --- */
        .chart-container {
            height: 250px; display: flex; align-items: flex-end; justify-content: space-between; padding-bottom: 10px;
        }
        .bar-wrapper {
            height: 100%; display: flex; flex-direction: column; justify-content: flex-end; align-items: center; width: 100%;
        }
        .bar {
            width: 60%; background-color: #dc3545; border-radius: 8px 8px 0 0; 
            transition: height 0.5s ease; min-height: 2%;
            position: relative; /* Needed for tooltip */
            cursor: pointer;
        }
        
        /* --- NEW: INSTANT TOOLTIP --- */
        .bar:hover::after {
            content: attr(data-value); /* Shows the money amount */
            position: absolute;
            bottom: 100%; left: 50%; transform: translateX(-50%);
            background: #212529; color: #fff;
            padding: 5px 10px; border-radius: 5px;
            font-size: 0.75rem; font-weight: bold;
            white-space: nowrap; margin-bottom: 8px;
            z-index: 100; pointer-events: none;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            animation: popUp 0.2s ease-out;
        }
        /* Little triangle arrow */
        .bar:hover::before {
            content: ''; position: absolute;
            bottom: 100%; left: 50%; transform: translateX(-50%);
            border-width: 5px; border-style: solid;
            border-color: #212529 transparent transparent transparent;
            margin-bottom: -2px; z-index: 100;
        }
        @keyframes popUp { from { opacity: 0; transform: translate(-50%, 5px); } to { opacity: 1; transform: translate(-50%, 0); } }
        /* ------------------------ */

        .navbar-brand { font-family: 'Chewy', cursive; font-size: 1.5rem; }
    </style>
</head>
<body>
    
    <nav class="navbar navbar-dark bg-danger shadow-sm sticky-top py-3">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2" href="admin.php">
                <i class="bi bi-pie-chart-fill"></i> Pizza Hut Admin
            </a>
            <div class="d-flex gap-2">
                <a href="main.php" class="btn btn-sm btn-outline-light rounded-pill px-3 fw-bold d-flex align-items-center">
                    <i class="bi bi-globe me-2"></i> View Website
                </a>
                <a href="logout.php" class="btn btn-sm btn-light text-danger fw-bold rounded-pill px-3 d-flex align-items-center">
                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        
        <div class="row g-4 mb-5">
            <div class="col-lg-8">
                <div class="card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center py-3">
                        <h5 class="mb-0"><i class="bi bi-graph-up me-2"></i>Weekly Sales</h5>
                        <div class="small">Today: <span id="today-earnings" class="fw-bold text-warning">₱0.00</span></div>
                    </div>
                    <div class="card-body">
                        <div class="chart-container" id="sales-chart">
                            </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="row g-3 h-100">
                    <div class="col-6">
                        <a href="#orders" class="admin-link text-center h-100 d-flex flex-column justify-content-center">
                            <span class="admin-icon"><i class="bi bi-bell-fill"></i></span>
                            <span class="fw-bold">Orders</span>
                            <span class="badge bg-danger rounded-pill mt-2" id="total-orders">0</span>
                        </a>
                    </div>
                    <div class="col-6">
                        <a href="add_pizza.php" class="admin-link text-center h-100 d-flex flex-column justify-content-center">
                            <span class="admin-icon"><i class="bi bi-plus-circle-fill"></i></span>
                            <span class="fw-bold">Add Item</span>
                        </a>
                    </div>
                    <div class="col-6">
                        <a href="#pizzas" class="admin-link text-center h-100 d-flex flex-column justify-content-center">
                            <span class="admin-icon"><i class="bi bi-grid-fill"></i></span>
                            <span class="fw-bold">Menu</span>
                            <small class="text-muted"><?= $totalPizzas ?> Items</small>
                        </a>
                    </div>
                    <div class="col-6">
                        <a href="#users" class="admin-link text-center h-100 d-flex flex-column justify-content-center">
                            <span class="admin-icon"><i class="bi bi-people-fill"></i></span>
                            <span class="fw-bold">Users</span>
                            <small class="text-muted"><?= $totalUsers ?> Registered</small>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-5 border-0 shadow" id="orders">
            <div class="card-header py-3 bg-danger text-white d-flex align-items-center">
                <h4 class="mb-0 flex-grow-1"><i class="bi bi-receipt me-2"></i>Incoming Orders</h4>
                <div class="spinner-grow spinner-grow-sm text-light" role="status"></div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr><th>Order ID</th><th>Customer</th><th>Status</th><th>Total & Payment</th><th>Action</th></tr>
                        </thead>
                        <tbody id="orders-tbody">
                            <tr><td colspan="5" class="text-center py-5"><div class="spinner-border text-danger"></div></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="card mb-5" id="pizzas">
            <div class="card-header py-3 bg-dark text-white">
                <h4 class="mb-0"><i class="bi bi-pizza me-2"></i>Manage Menu</h4>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr><th>Image</th><th>Name</th><th>Price</th><th>Availability</th><th>Action</th></tr>
                        </thead>
                        <tbody>
                            <?php while($pizza = $pizzaResult->fetch_assoc()): ?>
                            <tr>
                                <td><img src="<?= $pizza['image'] ?>" width="60" class="rounded shadow-sm"></td>
                                <td class="fw-bold"><?= $pizza['name'] ?></td>
                                <td>₱<?= number_format($pizza['price'], 2) ?></td>
                                <td>
                                    <form method="POST">
                                        <input type="hidden" name="pizza_id" value="<?= $pizza['id'] ?>">
                                        <input type="hidden" name="current_status" value="<?= $pizza['is_available'] ?>">
                                        <input type="hidden" name="toggle_stock" value="1">
                                        <?php if($pizza['is_available']): ?>
                                            <button class="btn btn-sm btn-success rounded-pill px-3 fw-bold"><i class="bi bi-check-lg"></i> In Stock</button>
                                        <?php else: ?>
                                            <button class="btn btn-sm btn-secondary rounded-pill px-3 fw-bold">Sold Out</button>
                                        <?php endif; ?>
                                    </form>
                                </td>
                                <td>
                                    <form method="POST" class="d-inline" onsubmit="return confirm('Delete item?');">
                                        <input type="hidden" name="pizza_id" value="<?= $pizza['id'] ?>">
                                        <input type="hidden" name="delete_pizza" value="1">
                                        <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="card mb-4" id="users">
            <div class="card-header py-3 bg-dark text-white">
                <h4 class="mb-0"><i class="bi bi-people me-2"></i>Registered Users</h4>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr><th>ID</th><th>Username</th><th>Email</th><th>Address</th><th>Action</th></tr>
                        </thead>
                        <tbody>
                            <?php while($user = $userResult->fetch_assoc()): ?>
                            <tr>
                                <td><?= $user['id'] ?></td>
                                <td class="fw-bold"><?= $user['username'] ?></td>
                                <td><?= $user['email'] ?></td>
                                <td class="small text-muted"><?= substr($user['address'], 0, 30) ?>...</td>
                                <td>
                                    <?php if(!$user['is_admin']): ?>
                                    <form method="POST" onsubmit="return confirm('Delete user?');">
                                        <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                        <input type="hidden" name="delete_user" value="1">
                                        <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                    </form>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark">Admin</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // AUTO REFRESH
    setInterval(function() {
        fetch('admin_refresh.php')
            .then(response => response.json())
            .then(data => {
                document.getElementById('today-earnings').textContent = '₱' + parseFloat(data.today_earnings).toLocaleString('en-PH', {minimumFractionDigits: 2});
                document.getElementById('total-orders').textContent = data.total_orders;
                updateGraph(data.last_7_days);
                
                const tableBody = document.getElementById('orders-tbody');
                if (tableBody && tableBody.innerHTML !== data.orders_html) {
                    tableBody.innerHTML = data.orders_html;
                }
            });
    }, 5000);

    // GRAPH RENDERER
    function updateGraph(graphData) {
        const container = document.getElementById('sales-chart');
        container.innerHTML = '';
        const target = 10000; // Goal
        
        graphData.forEach(data => {
            let pct = (data.amount / target) * 100;
            if(pct > 100) pct = 100;
            if(pct < 5) pct = 5;
            
            // Format amount for the tooltip
            let fmtAmount = '₱' + parseFloat(data.amount).toLocaleString('en-PH', {minimumFractionDigits: 2});

            const col = document.createElement('div');
            col.className = 'bar-wrapper';
            col.innerHTML = `
                <div class="bar" style="height: ${pct}%" data-value="${fmtAmount}"></div>
                <div class="small fw-bold mt-1">${data.day}</div>
                <div class="small text-muted" style="font-size:10px">${new Date(data.date).toLocaleDateString('en-US', {month:'short', day:'numeric'})}</div>
            `;
            container.appendChild(col);
        });
    }
    </script>
</body>
</html>