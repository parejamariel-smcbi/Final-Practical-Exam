<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    exit;
}

$userId = $_SESSION['user_id'];

// 1. Fetch Orders (Grouped by Order ID)
// We use Prepared Statements for security
$stmt = $conn->prepare("
    SELECT order_group_id, order_date, status, SUM(total_price) as total
    FROM orders 
    WHERE user_id = ? 
    GROUP BY order_group_id 
    ORDER BY order_date DESC
");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo '<div class="d-flex flex-column gap-3">'; // Wrapper for cards

    while($order = $result->fetch_assoc()) {
        $status = $order['status'];
        $orderId = $order['order_group_id'];
        $date = date('M d, Y • h:i A', strtotime($order['order_date']));
        $total = number_format($order['total'], 2);

        // Status Styling
        $badgeClass = 'bg-warning text-dark';
        $icon = '<i class="bi bi-hourglass-split"></i>';
        
        if($status == 'preparing') { 
            $badgeClass = 'bg-info text-dark'; 
            $icon = '<i class="bi bi-fire"></i>'; 
        }
        if($status == 'delivered') { 
            $badgeClass = 'bg-success'; 
            $icon = '<i class="bi bi-check-circle-fill"></i>'; 
        }
        if($status == 'cancelled') { 
            $badgeClass = 'bg-danger'; 
            $icon = '<i class="bi bi-x-circle-fill"></i>'; 
        }

        // --- START OF CARD HTML ---
        echo '
        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div>
                        <h5 class="fw-bold mb-1">Order #' . substr($orderId, 0, 8) . '</h5>
                        <small class="text-muted">' . $date . '</small>
                    </div>
                    <span class="badge ' . $badgeClass . ' rounded-pill px-3 py-2">
                        ' . $icon . ' ' . ucfirst($status) . '
                    </span>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3 border-top border-light">
                    <div>
                        <small class="text-muted text-uppercase fw-bold" style="font-size: 0.7rem;">Total Bill</small>
                        <div class="fs-4 fw-bold text-danger">₱' . $total . '</div>
                    </div>

                    ' . ($status == 'pending' ? '
                        <form method="POST" onsubmit="return confirm(\'Are you sure you want to cancel this order?\');">
                            <input type="hidden" name="group_id" value="' . $orderId . '">
                            <input type="hidden" name="cancel_order_group" value="1">
                            <button type="submit" class="btn btn-outline-danger btn-sm rounded-pill px-3 fw-bold">
                                Cancel Order
                            </button>
                        </form>
                    ' : '') . '
                    
                    ' . (($status == 'delivered' || $status == 'cancelled') ? '
                        <a href="menu.php" class="btn btn-light btn-sm rounded-pill px-3 text-muted">
                            Order Again
                        </a>
                    ' : '') . '
                </div>
            </div>
        </div>';
        // --- END OF CARD ---
    }
    echo '</div>'; // End wrapper

} else {
    // Empty State
    echo '
    <div class="text-center py-5">
        <div class="mb-3">
            <i class="bi bi-cart-x display-1 text-muted opacity-25"></i>
        </div>
        <h4 class="text-muted">No orders yet</h4>
        <p class="text-muted small">Looks like you haven\'t ordered anything.</p>
        <a href="menu.php" class="btn btn-danger rounded-pill px-4 mt-2">Browse Menu</a>
    </div>';
}
?>