<?php
session_start();
$isLoggedIn = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Pizza Hut | Hot & Fresh</title>
  <link rel="icon" href="icon.png" type="image/png">
  
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Chewy&family=Poppins:wght@300;400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  
  <style>
    body { font-family: 'Poppins', sans-serif; overflow-x: hidden; background-color: #fff; }
    h1, h2, h3 { font-family: 'Chewy', cursive; }

    /* --- HERO SECTION (SPLIT LAYOUT) --- */
    .hero-section {
        min-height: 100vh;
        background: linear-gradient(135deg, #fff8e1 0%, #ffecb3 100%);
        display: flex;
        align-items: center;
        position: relative;
        padding-top: 80px;
    }

    .hero-text h1 {
        font-size: 5rem;
        line-height: 1;
        color: #d32f2f;
        margin-bottom: 20px;
    }

    .hero-text p {
        font-size: 1.3rem;
        color: #5d4037;
        margin-bottom: 40px;
    }

    /* THE FLOATING PIZZA IMAGE */
    .hero-img-container {
        position: relative;
        z-index: 2;
    }

    .hero-img {
        width: 100%;
        max-width: 600px;
        border-radius: 50%;
        box-shadow: 0 30px 80px rgba(211, 47, 47, 0.3);
        animation: float 6s ease-in-out infinite;
        border: 10px solid white;
    }

    @keyframes float {
        0% { transform: translateY(0px) rotate(0deg); }
        50% { transform: translateY(-20px) rotate(2deg); }
        100% { transform: translateY(0px) rotate(0deg); }
    }

    .btn-main {
        background-color: #d32f2f;
        color: white;
        padding: 15px 50px;
        font-size: 1.3rem;
        font-weight: bold;
        border-radius: 50px;
        box-shadow: 0 10px 25px rgba(211, 47, 47, 0.4);
        transition: 0.3s;
        border: none;
    }
    .btn-main:hover {
        background-color: #b71c1c;
        transform: translateY(-5px);
        box-shadow: 0 15px 35px rgba(211, 47, 47, 0.6);
        color: white;
    }

    /* --- FEATURE CARDS --- */
    .feature-section { padding: 100px 0; background: white; }
    
    .card-hover {
        border: none;
        border-radius: 20px;
        padding: 30px;
        background: #fff;
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        transition: 0.3s;
        text-align: center;
        border-bottom: 5px solid transparent;
    }
    .card-hover:hover {
        transform: translateY(-10px);
        border-bottom: 5px solid #ffca28;
        box-shadow: 0 20px 40px rgba(0,0,0,0.1);
    }
    .icon-circle {
        width: 70px; height: 70px;
        background: #fff3e0;
        color: #ff9800;
        border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-size: 2rem; margin: 0 auto 20px;
    }

    /* Mobile Fixes */
    @media(max-width: 991px) {
        .hero-section { text-align: center; padding-bottom: 50px; }
        .hero-text h1 { font-size: 3.5rem; }
        .hero-img { max-width: 300px; margin-top: 40px; }
    }
  </style>
</head>
<body class="d-flex flex-column min-vh-100">

<?php include 'navbar.php'; ?>

<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 hero-text" data-aos="fade-right">
                <span class="text-warning fw-bold text-uppercase ls-2">Hungry?</span>
                <h1>IT'S NOT JUST<br>PIZZA, IT'S<br><span class="text-warning">LOVE.</span></h1>
                <p>Hand-tossed dough, garden-fresh toppings, and 100% real mozzarella. Delivered hotter than summer.</p>
                <div class="d-flex gap-3 justify-content-lg-start justify-content-center">
                    <a href="menu.php" class="btn btn-main">ORDER NOW <i class="bi bi-chevron-right"></i></a>
                    <a href="menu.php" class="btn btn-outline-danger rounded-pill px-4 py-3 fw-bold">VIEW MENU</a>
                </div>
            </div>
            
            <div class="col-lg-6 text-center hero-img-container" data-aos="zoom-in" data-aos-delay="200">
                <img src="https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80" class="hero-img" alt="Delicious Pizza">
            </div>
        </div>
    </div>
</section>

<section class="feature-section">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4" data-aos="fade-up">
                <div class="card-hover">
                    <div class="icon-circle"><i class="bi bi-stopwatch-fill"></i></div>
                    <h4>Fast Delivery</h4>
                    <p class="text-muted">We delivery faster than you can say "Pepperoni".</p>
                </div>
            </div>
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                <div class="card-hover">
                    <div class="icon-circle text-danger bg-danger-subtle"><i class="bi bi-fire"></i></div>
                    <h4>Fresh from Oven</h4>
                    <p class="text-muted">Baked to perfection and delivered piping hot.</p>
                </div>
            </div>
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
                <div class="card-hover">
                    <div class="icon-circle text-success bg-success-subtle"><i class="bi bi-check-lg"></i></div>
                    <h4>Best Taste</h4>
                    <p class="text-muted">Rated #1 Pizza in town by our lovely customers.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  AOS.init({
    duration: 800,
    once: true
  });
</script>

</body>
</html>