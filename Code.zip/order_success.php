<?php
session_start();
include 'db.php'; 
$isLoggedIn = isset($_SESSION['user_id']);

$orderGroupId = $_SESSION['order_group_id'] ?? null;
$successMessage = $_SESSION['success_message'] ?? 'Thank you for your order!';

// Clear session vars after loading
if(isset($_SESSION['success_message'])) unset($_SESSION['success_message']);
if(isset($_SESSION['order_group_id'])) unset($_SESSION['order_group_id']);

// Fetch Order Details for Receipt
$orderItems = [];
$orderMeta = [];
$totalPaid = 0;
$userName = '';

if ($orderGroupId) {
    $sql = "SELECT o.*, p.name as pizza_name, p.price as unit_price, u.username, u.email, u.address as user_address
            FROM orders o 
            JOIN pizzas p ON o.pizza_id = p.id 
            JOIN users u ON o.user_id = u.id
            WHERE o.order_group_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $orderGroupId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $orderItems[] = $row;
        $totalPaid += $row['total_price'];
        if (empty($orderMeta)) {
            $orderMeta = [
                'date' => $row['order_date'],
                'address' => $row['delivery_address'],
                'instructions' => $row['custom_instructions']
            ];
            $userName = $row['username'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Order Confirmed | Pizza Hut</title>
  <link rel="icon" href="icon.png" type="image/png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Chewy&family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

  <style>
    body { font-family: 'Poppins', sans-serif; background-color: #f4f4f4; }
    h1, h5 { font-family: 'Chewy', cursive; }
    .success-card { background: white; border-radius: 20px; padding: 40px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); text-align: center; max-width: 600px; margin: 50px auto; }
    .check-icon { font-size: 5rem; color: #4caf50; margin-bottom: 20px; }
    .receipt-box { background: #f9f9f9; border: 2px dashed #ddd; border-radius: 15px; padding: 20px; text-align: left; margin-top: 30px; }
    
    /* Print Styles */
    @media print {
      body { background: white; }
      .no-print { display: none !important; }
      .success-card { box-shadow: none; margin: 0; padding: 20px; }
      .receipt-box { border: 2px solid #333; page-break-inside: avoid; }
      .print-header { display: block !important; text-align: center; margin-bottom: 20px; }
      .print-logo { font-size: 2rem; color: #d32f2f; font-family: 'Chewy', cursive; }
      .print-divider { border-top: 2px dashed #333; margin: 15px 0; }
    }
    
    .print-header { display: none; }
    
    .btn-print {
      background: linear-gradient(135deg, #2196f3 0%, #1976d2 100%);
      color: white;
      border: none;
      padding: 12px 30px;
      border-radius: 50px;
      font-weight: bold;
      box-shadow: 0 5px 15px rgba(33, 150, 243, 0.3);
      transition: all 0.3s;
    }
    
    .btn-print:hover {
      transform: translateY(-3px);
      box-shadow: 0 8px 20px rgba(33, 150, 243, 0.4);
      color: white;
    }
  </style>
</head>
<body class="d-flex flex-column min-vh-100">

  <div class="no-print">
    <?php include 'navbar.php'; ?>
  </div>

  <div class="container flex-grow-1">
    <div class="success-card" id="receiptContent">
        
        <!-- Print Header (Only shows when printing) -->
        <div class="print-header">
            <div class="print-logo">🍕 Pizza Hut</div>
            <p class="mb-0">Managa, Bansalan, Davao Del Sur</p>
            <p class="mb-0">📞 +63 912 345 6789</p>
            <p class="small text-muted">support@pizzahut.com</p>
            <div class="print-divider"></div>
        </div>

        <div class="no-print">
            <i class="bi bi-check-circle-fill check-icon"></i>
            <h1 class="text-success">Order Placed!</h1>
            <p class="lead text-muted"><?= htmlspecialchars($successMessage) ?></p>
            
            <div class="alert alert-warning rounded-pill d-inline-block px-4">
                <i class="bi bi-stopwatch-fill"></i> Estimated Delivery: <strong>30 - 45 Mins</strong>
            </div>
        </div>

        <?php if (!empty($orderItems)): ?>
        <div class="receipt-box">
            <h5 class="border-bottom pb-2 mb-3 text-dark">🧾 Order Receipt</h5>
            
            <div class="mb-3">
                <div class="d-flex justify-content-between mb-1">
                    <span class="text-muted small">Order ID:</span>
                    <span class="fw-bold small"><?= htmlspecialchars($orderGroupId) ?></span>
                </div>
                <div class="d-flex justify-content-between mb-1">
                    <span class="text-muted small">Customer:</span>
                    <span class="fw-bold small"><?= htmlspecialchars($userName) ?></span>
                </div>
                <div class="d-flex justify-content-between mb-1">
                    <span class="text-muted small">Date:</span>
                    <span class="fw-bold small"><?= date('M d, Y - h:i A', strtotime($orderMeta['date'])) ?></span>
                </div>
            </div>
            
            <hr>
            
            <div class="mb-3">
                <strong class="d-block mb-2">Items Ordered:</strong>
                <?php foreach ($orderItems as $item): ?>
                <div class="d-flex justify-content-between mb-2">
                    <span>
                        <?= htmlspecialchars($item['pizza_name']) ?> 
                        <span class="text-muted">x<?= $item['quantity'] ?></span>
                    </span>
                    <span class="fw-bold">₱<?= number_format($item['total_price'], 2) ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            
            <hr>
            
            <div class="d-flex justify-content-between fs-5 text-danger fw-bold mb-3">
                <span>Total Paid</span>
                <span>₱<?= number_format($totalPaid, 2) ?></span>
            </div>

            <div class="small text-muted">
                <p class="mb-1"><i class="bi bi-geo-alt-fill"></i> <strong>Deliver to:</strong> <?= htmlspecialchars($orderMeta['address']) ?></p>
                <?php if (!empty($orderMeta['instructions'])): ?>
                    <p class="mb-0 text-warning-emphasis"><i class="bi bi-exclamation-circle-fill"></i> <strong>Note:</strong> <?= htmlspecialchars($orderMeta['instructions']) ?></p>
                <?php endif; ?>
            </div>
            
            <div class="text-center mt-4 pt-3 border-top no-print">
                <p class="small text-muted mb-0">Thank you for your order!</p>
                <p class="small text-muted">For support, call: <strong>+63 912 345 6789</strong></p>
            </div>
        </div>
        <?php endif; ?>

        <div class="mt-4 d-grid gap-2 d-sm-flex justify-content-center no-print">
            <button onclick="window.print()" class="btn btn-print">
                <i class="bi bi-printer-fill me-2"></i>Print Receipt
            </button>
            <a href="profile.php" class="btn btn-dark rounded-pill px-4 py-2">
                <i class="bi bi-clock-history me-2"></i>Track Order
            </a>
            <a href="menu.php" class="btn btn-outline-danger rounded-pill px-4 py-2">
                <i class="bi bi-arrow-repeat me-2"></i>Order More
            </a>
        </div>
    </div>
  </div>

  <div class="no-print">
    <?php include 'footer.php'; ?>
  </div>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  
  <script>
    // Auto-print option (optional - uncomment if you want)
    // window.addEventListener('load', function() {
    //     setTimeout(() => {
    //         if (confirm('Would you like to print your receipt?')) {
    //             window.print();
    //         }
    //     }, 1000);
    // });
  </script>
</body>
</html>