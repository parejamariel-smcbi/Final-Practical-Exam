<?php
session_start();
include 'db.php';

// 🔐 Security: Admin Only
if (!isset($_SESSION['user_id']) || empty($_SESSION['is_admin'])) {
    header("Location: main.php");
    exit;
}

$id = $_GET['id'] ?? null;

if ($id) {
    $stmt = $conn->prepare("DELETE FROM pizzas WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

header("Location: admin.php");
exit;
?>