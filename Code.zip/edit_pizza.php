<?php
session_start();
include 'db.php';

// Admin Check
if (!isset($_SESSION['user_id']) || empty($_SESSION['is_admin'])) {
    header("Location: main.php");
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) { header("Location: admin.php"); exit; }

// Fetch
$stmt = $conn->prepare("SELECT * FROM pizzas WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$pizza = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $category = $_POST['category'];
        if (!empty($_FILES['image']['name'])) {
        $fileInfo = pathinfo($_FILES['image']['name']);
        $extension = strtolower($fileInfo['extension']);
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        // Validate Extension
        if (!in_array($extension, $allowedExtensions)) {
            echo "<script>alert('Error: Only JPG, JPEG, PNG, and GIF files are allowed.'); window.location='admin.php';</script>";
            exit;
        }

        $uniqueName = uniqid() . '.' . $extension;
        $target = $uniqueName;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            // Delete old image if it's not the default
            if ($pizza['image'] != 'default_item.png' && file_exists($pizza['image'])) {
                unlink($pizza['image']);
            }
            
            $image = $uniqueName;
            $stmt = $conn->prepare("UPDATE pizzas SET name=?, description=?, price=?, image=?, category=? WHERE id=?");
            $stmt->bind_param("ssdssi", $name, $description, $price, $image, $category, $id);
        } else {
            echo "<script>alert('Error uploading file.'); window.location='admin.php';</script>";
            exit;
        }
    } else {
        // Update without changing image
        $stmt = $conn->prepare("UPDATE pizzas SET name=?, description=?, price=?, category=? WHERE id=?");
        $stmt->bind_param("ssdsi", $name, $description, $price, $category, $id);
    }

    
    } else {
        $stmt = $conn->prepare("UPDATE pizzas SET name=?, description=?, price=?, category=? WHERE id=?");
        $stmt->bind_param("ssdsi", $name, $description, $price, $category, $id);
    }
    
    if ($stmt->execute()) {
        echo "<script>alert('Item updated!'); window.location='admin.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Item | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>body { font-family: 'Poppins', sans-serif; background: #f4f6f9; }</style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-sm border-0 rounded-4">
                    <div class="card-header bg-primary text-white text-center py-3 rounded-top-4">
                        <h4 class="mb-0">Edit Menu Item</h4>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Item Name</label>
                                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($pizza['name']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Category</label>
                                <select name="category" class="form-select" required>
                                    <option value="all" <?= $pizza['category']=='all'?'selected':'' ?>>Standard Pizza</option>
                                    <option value="bestseller" <?= $pizza['category']=='bestseller'?'selected':'' ?>>Bestseller</option>
                                    <option value="spicy" <?= $pizza['category']=='spicy'?'selected':'' ?>>Spicy</option>
                                    <option value="veggie" <?= $pizza['category']=='veggie'?'selected':'' ?>>Veggie</option>
                                    <option value="drinks" <?= $pizza['category']=='drinks'?'selected':'' ?>>🍹 Drinks</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Description</label>
                                <textarea name="description" class="form-control" rows="3" required><?= htmlspecialchars($pizza['description']) ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Price (₱)</label>
                                <input type="number" step="0.01" name="price" class="form-control" value="<?= $pizza['price'] ?>" required>
                            </div>
                            <div class="mb-4 text-center">
                                <img src="<?= htmlspecialchars($pizza['image']) ?>" class="rounded mb-2" width="100"><br>
                                <label class="small text-muted">Upload new image to replace</label>
                                <input type="file" name="image" class="form-control" accept="image/*">
                            </div>
                            <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Update Changes</button>
                            <a href="admin.php" class="btn btn-outline-secondary w-100 mt-2">Cancel</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>