<style>
    .footer { background-color: #212529; color: white; padding: 50px 0 20px; margin-top: auto; }
    .footer h5 { font-family: 'Chewy', cursive; color: #ffca28; margin-bottom: 20px; }
    .footer a { color: rgba(255,255,255,0.7); text-decoration: none; transition: 0.3s; }
    .footer a:hover { color: #ffca28; }
    .social-icon { font-size: 1.5rem; margin-right: 15px; }
</style>

<footer class="footer">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4 col-md-6">
                <h5>Pizza Hut</h5>
                <p class="small text-white-50">Delivering slices of happiness directly to your doorstep. Fresh ingredients, hot ovens, and fast drivers.</p>
                <div class="mt-3">
                    <a href="https://facebook.com" target="_blank" class="social-icon"><i class="bi bi-facebook"></i></a>
                    <a href="https://instagram.com" target="_blank" class="social-icon"><i class="bi bi-instagram"></i></a>
                    <a href="https://twitter.com" target="_blank" class="social-icon"><i class="bi bi-twitter-x"></i></a>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li class="mb-2"><a href="menu.php">Order Pizza</a></li>
                    <li class="mb-2"><a href="profile.php">Track Order</a></li>
                    <li class="mb-2"><a href="contact.php">Contact Support</a></li>
                </ul>
            </div>

            <div class="col-lg-4 col-md-12">
                <h5>Contact Us</h5>
                <ul class="list-unstyled small text-white-50">
                    <li class="mb-2"><i class="bi bi-geo-alt-fill text-warning me-2"></i> Managa, Bansalan, Davao Del Sur</li>
                    <li class="mb-2"><i class="bi bi-telephone-fill text-warning me-2"></i> +63 912 345 6789</li>
                    <li class="mb-2"><i class="bi bi-envelope-fill text-warning me-2"></i> support@pizzahut.com</li>
                </ul>
            </div>
        </div>
        
        <hr class="my-4 border-secondary">
        
        <div class="text-center small text-white-50">
            &copy; <?= date('Y') ?> Pizza Hut. All Rights Reserved.
        </div>
    </div>
</footer>