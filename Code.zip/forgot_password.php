<?php
session_start();
include 'db.php';

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    
    $stmt = $conn->prepare("SELECT id, username FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        $updateStmt = $conn->prepare("UPDATE users SET reset_token = ?, reset_expiry = ? WHERE email = ?");
        $updateStmt->bind_param("sss", $token, $expiry, $email);
        $updateStmt->execute();
        
        $resetLink = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/reset_password.php?token=" . $token;
        
        $message = "Password reset instructions generated! <br> <a href='$resetLink' class='fw-bold text-decoration-underline'>Click here to Reset Password</a>";
        $messageType = 'success';
    } else {
        $message = "We couldn't find an account with that email address.";
        $messageType = 'danger';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password | Pizza Hut</title>
    <link rel="icon" href="icon.png" type="image/png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Chewy&family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        body { 
            font-family: 'Poppins', sans-serif; 
            background: #f4f4f4; 
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        h1, h2, h3, h4, h5 { font-family: 'Chewy', cursive; }
        
        .auth-card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            overflow: hidden;
            max-width: 450px;
            width: 100%;
        }
        
        .auth-header {
            background: #d32f2f;
            padding: 30px;
            text-align: center;
            color: white;
        }
        
        .form-control {
            border-radius: 10px; padding: 12px 15px; border: 1px solid #eee; background: #f8f9fa;
        }
        .form-control:focus {
            box-shadow: none; border-color: #d32f2f; background: white;
        }
        
        .btn-pizza {
            background: #d32f2f; color: white; border: none; border-radius: 50px;
            padding: 12px; font-weight: bold; transition: all 0.3s;
        }
        .btn-pizza:hover { background: #b71c1c; transform: translateY(-2px); color: white; }
        
        .icon-circle {
            width: 80px; height: 80px; background: rgba(255,255,255,0.2);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            margin: 0 auto 15px; font-size: 2.5rem;
        }
    </style>
</head>
<body>

    <div class="container p-3">
        <div class="auth-card mx-auto bg-white">
            
            <div class="auth-header">
                <div class="icon-circle">
                    <i class="bi bi-key-fill"></i>
                </div>
                <h2 class="mb-0">Forgot Password?</h2>
                <p class="mb-0 opacity-75 small">Let's get you back into your account</p>
            </div>
            
            <div class="p-4 p-md-5">
                <?php if ($message): ?>
                    <div class="alert alert-<?= $messageType ?> rounded-3 border-0 shadow-sm mb-4" role="alert">
                        <i class="bi bi-<?= $messageType == 'success' ? 'check-circle' : 'exclamation-circle' ?>-fill me-2"></i>
                        <?= $message ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="mb-4">
                        <label class="form-label fw-bold text-muted small text-uppercase">Email Address</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-0 rounded-start-3 ps-3"><i class="bi bi-envelope text-danger"></i></span>
                            <input type="email" name="email" class="form-control border-0 bg-light" placeholder="Enter your registered email" required>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-pizza w-100 mb-4 shadow-sm">
                        Send Reset Link <i class="bi bi-arrow-right ms-2"></i>
                    </button>
                    
                    <div class="text-center border-top pt-4">
                        <a href="main.php" class="btn btn-light rounded-pill px-4 fw-semibold text-muted">
                            <i class="bi bi-house-door-fill me-2 text-danger"></i> Back to Website
                        </a>
                    </div>
                </form>
            </div>
            
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>