<?php
session_start();
include 'db.php'; 

// 1. Security & Session Check
if (!isset($_SESSION['user_id'])) {
    header("Location: main.php");
    exit;
}

$userId = $_SESSION['user_id'];
$cart = $_SESSION['cart'] ?? [];

// 2. Validate Cart
if (empty($cart)) {
    $_SESSION['error_message'] = "Your cart is empty.";
    header("Location: order.php");
    exit;
}

// 3. Capture Form Data
$deliveryAddress = trim($_POST['delivery_address'] ?? '');
$rawInstructions = trim($_POST['custom_instructions'] ?? '');
$paymentMethod = $_POST['payment_method'] ?? 'COD'; 

// Build payment details string based on payment method
$paymentDetails = "[$paymentMethod]";

switch ($paymentMethod) {
    case 'GCash':
        $gNumber = $_POST['gcash_number'] ?? 'N/A';
        $gRef = $_POST['gcash_ref'] ?? 'N/A';
        $paymentDetails = "[GCash: $gNumber | Ref: $gRef]";
        break;
        
    case 'Maya':
        $mNumber = $_POST['maya_number'] ?? 'N/A';
        $mRef = $_POST['maya_ref'] ?? 'N/A';
        $paymentDetails = "[Maya: $mNumber | Ref: $mRef]";
        break;
        
    case 'Bank Transfer':
        $bRef = $_POST['bank_ref'] ?? 'N/A';
        $paymentDetails = "[Bank Transfer | Ref: $bRef]";
        break;
        
    case 'COD':
    default:
        $paymentDetails = "[Cash on Delivery]";
        break;
}

// Combine payment details with custom instructions
$customInstructions = $paymentDetails;
if (!empty($rawInstructions)) {
    $customInstructions .= " | Note: " . $rawInstructions;
}

// Fallback to profile address if user left it blank
if (empty($deliveryAddress)) {
    $stmt = $conn->prepare("SELECT address FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $deliveryAddress = $row['address'];
    $stmt->close();
}

// Generate a unique Group ID
$orderGroupId = uniqid('ORD-'); 
$totalOrderValue = 0;

// 4. START TRANSACTION
$conn->begin_transaction();

try {
    // Insert Query
    $sql = "INSERT INTO orders (user_id, pizza_id, quantity, total_price, delivery_address, order_group_id, custom_instructions) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    foreach ($cart as $pizzaId => $item) {
        $quantity = $item['quantity'];

        // Fetch latest price
        $priceStmt = $conn->prepare("SELECT price FROM pizzas WHERE id = ?");
        $priceStmt->bind_param("i", $pizzaId);
        $priceStmt->execute();
        $pizzaResult = $priceStmt->get_result();
        $pizzaData = $pizzaResult->fetch_assoc();
        $priceStmt->close();

        if (!$pizzaData) {
            throw new Exception("One of the pizzas is no longer available.");
        }

        $itemPrice = $pizzaData['price'] * $quantity;
        $totalOrderValue += $itemPrice;

        // Bind Parameters: UserID(i), PizzaID(i), Qty(i), Price(d), Address(s), GroupID(s), Instructions(s)
        $stmt->bind_param("iiidsss", $userId, $pizzaId, $quantity, $itemPrice, $deliveryAddress, $orderGroupId, $customInstructions);
        
        if (!$stmt->execute()) {
            throw new Exception("Database Insert Failed: " . $conn->error);
        }
    }
    $stmt->close();

    // 5. Commit Transaction
    $conn->commit();

    // Success
    $_SESSION['order_group_id'] = $orderGroupId; 
    $_SESSION['success_message'] = "Order Placed Successfully!";
    
    unset($_SESSION['cart']); 
    header("Location: order_success.php");
    exit;

} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['error_message'] = "Order failed: " . $e->getMessage();
    header("Location: order.php");
    exit;
}
?>